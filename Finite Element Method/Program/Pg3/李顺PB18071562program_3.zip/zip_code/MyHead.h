#ifndef MyHead_
#define MyHead_
#include <iostream>
#include <iomanip>
#include <vector>
using namespace std;

//常数
#define OK 1
#define ERROR 0
//机器精度,以及另外两个可选的常数值
#define MACHINE_PRECISION_15 1e-15
#define MACHINE_TINY_8 1e-8
#define VIEW_SMALL_5 1e-5

typedef unsigned index;
typedef double T;
typedef int Status;

typedef std::vector<std::vector<T>> matrix;
typedef std::vector<std::vector<std::vector<T>>> supermatrix;

#define ITERATION_MAX 0xfffffff

#endif //MyHead_