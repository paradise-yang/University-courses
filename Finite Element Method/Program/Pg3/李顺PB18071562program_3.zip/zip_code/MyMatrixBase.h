#ifndef MyMatrixBase_
#define MyMatrixBase_
#include "MyHead.h"

enum reading_flag {
    reading_flag_none = 0,
    reading_flag_mma,
    reading_flag_12f,
};

// 基础实现vector
vector<T> newVector(index, T e = 0);
vector<T> newVector(const vector<T> &);
vector<T> operator+(const vector<T> &, const vector<T> &);
vector<T> operator-(const vector<T> &, const vector<T> &);
vector<T> operator*(T, const vector<T> &);
Status readVector(const vector<T> &, enum reading_flag = reading_flag_none);

// 基础实现matrix
matrix newMatrix(index, index, T e = 0);
matrix newMatrix(const matrix &);
matrix operator+(const matrix &, const matrix &);
matrix operator-(const matrix &, const matrix &);
matrix operator*(T x, const matrix &);
matrix transpose(const matrix &); //矩阵额外的转置
Status readMatrix(const matrix &, enum reading_flag = reading_flag_none);

// 基础实现supermatrix
supermatrix newSuperMatrix(index, index,index, T e = 0);
supermatrix newSuperMatrix(const supermatrix &);
supermatrix operator+(const supermatrix &, const supermatrix &);
supermatrix operator-(const supermatrix &, const supermatrix &);
supermatrix operator*(T, const supermatrix &);
Status readSuperMatrix(const supermatrix &, enum reading_flag = reading_flag_mma);

T vectorMultiplyvector(const vector<T> &, const vector<T> &);          //向量点乘向量得到值
matrix vectorTensorvector(const vector<T> &, const vector<T> &);       //向量的张量积得到矩阵
vector<T> matrixMultiplyvector(const matrix &, const vector<T> &);     //矩阵乘以向量
vector<T> diagmatrixMultiplyvector(const matrix &, const vector<T> &); //对角矩阵乘以向量的快速乘法
matrix matrixMultiplymatrix(const matrix &, const matrix &);           //矩阵乘法得到矩阵
//高级运算符重载，它们直接通过上述函数实现，不是独立的
T operator*(const vector<T> &, const vector<T> &);      //向量点乘向量得到值
matrix operator^(const vector<T> &, const vector<T> &); //向量和向量张成矩阵
vector<T> operator*(const matrix &, const vector<T> &); //矩阵乘以向量得到向量
matrix operator*(const matrix &, const matrix &);       //矩阵乘法得到矩阵


// ostream
//之前的read函数使用printf实现，这里使用cout，配套MyLog.h
std::ostream &operator<<(std::ostream &, const vector<T> &);
std::ostream &operator<<(std::ostream &, const matrix &);
std::ostream &operator<<(std::ostream &, const supermatrix &);

#endif // MyMatrixBase_