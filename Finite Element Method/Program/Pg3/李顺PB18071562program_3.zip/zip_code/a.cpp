#include "MyMatrixBase.h"
#include "flag.h"
#include <cmath>

T test_f(T x)
{
    return x;
}

T test_u(T ep, T x)
{
    if (ep >= 1e-2) {
        T c1 = ep * x + x * x / 2;
        T c2 = (exp(x / ep) - 1) / (exp(1 / ep) - 1);
        return c1 - (ep + 0.5) * c2;
    }
    else {
        T c1 = ep * x;
        T c0 = x * x / 2;
        T c2 = (x - 1.0) / ep;
        return c0 + c1 - (ep + 0.5) * exp(c2);
    }
}

T p0_left(T x)
{
    return (1.0 + x) / 2;
}

T p0_right(T x)
{
    return (1.0 - x) / 2;
}

vector<T> thomas(const matrix &constA, const vector<T> &constd)
{
    index na = constA.size(), na2 = constA[0].size(), nd = constd.size();
    vector<T> x(na2, 0);
    if (na != na2 || na != nd) {
        printf("thomas:尺寸不相等\n");
        return x;
    }
    matrix A = constA;
    vector<T> d = constd;
    T temp = 0;
    for (index i = 1; i < na; i++) {
        temp = A[i][i - 1] / A[i - 1][i - 1];
        A[i][i] -= (temp * A[i - 1][i]);
        d[i] -= (temp * d[i - 1]);
    }

    x[na - 1] = d[na - 1] / A[na - 1][na - 1];
    for (index i = na - 1; i > 0; i--) {
        //注意下标
        x[i - 1] = (d[i - 1] - A[i - 1][i] * x[i]) / A[i - 1][i - 1];
    }
    return x;
}

matrix setMatrix_K(index n, T h1, T h2, T ep)
{
    index len = 2 * n;
    matrix K = newMatrix(len - 1, len - 1);
    //第一部分
    for (index i = 0; i < n - 1; i++) {
        K[i][i] = 2 / h1;
        if (i < n - 2)
            K[i][i + 1] = -1 / h1;
        if (i > 0)
            K[i][i - 1] = -1 / h1;
    }
    //交界部分
    K[n - 1][n - 1] = 1 / h1 + 1 / h2;
    K[n - 1][n - 2] = K[n - 2][n - 1] = -1 / h1;
    K[n - 1][n] = K[n][n - 1] = -1 / h2;

    //第二部分
    for (index i = n; i < len - 1; i++) {
        K[i][i] = 2 / h2;
        if (i < len - 2)
            K[i][i + 1] = -1 / h2;
        if (i > n)
            K[i][i - 1] = -1 / h2;
    }

    K = ep * K; //矩阵数乘
    //加上非对称项
    for (index i = 0; i < len - 1; i++) {
        if (i < len - 2) {
            K[i][i + 1] += 0.5;
        }
        if (i > 0) {
            K[i][i - 1] -= 0.5;
        }
    }

    return K;
}
/*
matrix setMatrix_K(index n, T h1, T h2, T ep)
{
    index len = 2 * n;
    matrix K = newMatrix(len - 1, len - 1);
    T cf = h2 / h1;
    //第一部分
    for (index i = 0; i < n - 1; i++) {
        K[i][i] = 2 * cf;
        if (i < n - 2)
            K[i][i + 1] = -1 * cf;
        if (i > 0)
            K[i][i - 1] = -1 * cf;
    }
    //交界部分
    K[n - 1][n - 1] = 1 + cf;
    K[n - 1][n - 2] = K[n - 2][n - 1] = -cf;
    K[n - 1][n] = K[n][n - 1] = -1;

    //第二部分
    for (index i = n; i < len - 1; i++) {
        K[i][i] = 2;
        if (i < len - 2)
            K[i][i + 1] = -1;
        if (i > n)
            K[i][i - 1] = -1;
    }

    K = ep * K; //矩阵数乘
    //加上非对称项
    for (index i = 0; i < len - 1; i++) {
        if (i < len - 2) {
            K[i][i + 1] += 0.5 * h2;
        }
        if (i > 0) {
            K[i][i - 1] -= 0.5 * h2;
        }
    }

    return K;
}
*/
vector<T> ordertest(const vector<T> &u)
{
    index len = u.size();
    vector<T> v(len, 0);
    for (index i = 1; i < len; i++) {
        v[i] = -log(u[i] / u[i - 1]) / log(2);
    }

    return v;
}

T gauss_integrate(T (*f)(T x), T (*p)(T x), T xleft, T xright)
{
    // 3个点的gauss积分公式
    vector<T> points = {-sqrt(0.6), 0, sqrt(0.6)};
    vector<T> weights = {5.0 / 9, 8.0 / 9, 5.0 / 9};
    // vector<T> weights = {0.1294849661688690, 0.2797053914892760, 0.3818300505051180, 0.4179591836734690, 0.3818300505051180, 0.2797053914892760, 0.1294849661688690};
    // vector<T> points = {-0.9491079123427580, -0.7415311855993940, -0.4058451513773970, 0, 0.4058451513773970, 0.7415311855993940, 0.9491079123427580};
    index gauss_k = 3;

    T s = 0;
    T xcenter = (xleft + xright) / 2;
    T h = xright - xleft;
    for (index i = 0; i < gauss_k; i++) {
        s = s + weights[i] * f(xcenter + h / 2 * points[i]) * p(points[i]);
    }
    s = s * h / 2;
    return s;
}

vector<T> fun_main(index n, T ep, T h1, T h2, const vector<T> &xlist, T (*f)(T x))
{
    index len = 2 * n;
    vector<T> d(len - 1);
    vector<T> f_times_p0_left(len, 0);
    vector<T> f_times_p0_right(len, 0);

    for (index i = 0; i < len; i++) {
        f_times_p0_left[i] = gauss_integrate(f, p0_left, xlist[i], xlist[i + 1]);
        f_times_p0_right[i] = gauss_integrate(f, p0_right, xlist[i], xlist[i + 1]);
    }

    for (index i = 0; i < len - 1; i++) {
        d[i] = f_times_p0_left[i] + f_times_p0_right[i + 1];
    }

    matrix K = setMatrix_K(n, h1, h2, ep);

    vector<T> uh = thomas(K, d);
#ifdef KDSHOW
    printf("K\n");
    readMatrix(K, reading_flag_mma);
    printf("d\n");
    readVector(d);
    printf("check\n");
    readVector(K * uh - d);
#endif
    return uh;
}

T evaluate(const vector<T> &uh, const vector<T> &xlist, T x)
{
    index len = xlist.size() - 1;
    index right_i, left_i;
    T s = 0;
    for (right_i = 1; right_i <= len; right_i++) {
        if (xlist[right_i] >= x) break;
    }
    left_i = right_i - 1;

    if (right_i == 1) {
        s = uh[right_i - 1] * (x - xlist[left_i]) / (xlist[right_i] - xlist[left_i]);
    }
    else if (right_i == len) {
        s = uh[left_i - 1] * (xlist[right_i] - x) / (xlist[right_i] - xlist[left_i]);
    }
    else {
        s = uh[right_i - 1] * (x - xlist[left_i]) / (xlist[right_i] - xlist[left_i]) + uh[left_i - 1] * (xlist[right_i] - x) / (xlist[right_i] - xlist[left_i]);
    }

    return s;
}

T error_L2(const vector<T> &uh, const vector<T> &xlist, T h1, T h2, T ep, T (*u)(T ep, T x), matrix &plots1, matrix &plots2)
{
    index len = xlist.size() - 1;
    index n = len / 2;
    index m = 3;
    vector<T> x_values(m * len, 0); //每个cell取9个十等分点，不含两个端点
    vector<T> uh_values(m * len, 0);
    vector<T> u_values(m * len, 0);
    vector<T> points = {-sqrt(0.6), 0, sqrt(0.6)};
    vector<T> weights = {5.0 / 9, 8.0 / 9, 5.0 / 9};

    plots1 = newMatrix(m * len, 2);
    plots2 = newMatrix(m * len, 2);

    T cell_length;

    for (index i = 0; i < len; i++) {
        if (i < n) {
            cell_length = h1;
        }
        else {
            cell_length = h2;
        }
        for (index j = 0; j < m; j++) {
            x_values[i * m + j] = xlist[i] + cell_length / 2 + cell_length / 2 * points[j];
        }
    }

    T sum = 0,tempsum=0;
    vector<T> temp = newVector(3, 0);
    for (index i = 0; i < len; i++) {
        tempsum=0;
        for (index j = 0; j < m; j++) {
            u_values[i * m + j] = u(ep, x_values[i * m + j]);
            uh_values[i * m + j] = evaluate(uh, xlist, x_values[i * m + j]);
            temp[j] = fabs(u_values[i * m + j] - uh_values[i * m + j]);
            tempsum = tempsum + weights[j] * temp[j]*temp[j];
            plots1[i][0] = x_values[i];
            plots1[i][1] = uh_values[i];
            plots2[i][0] = x_values[i];
            plots2[i][1] = u_values[i];
        }
        sum = sum + (xlist[i+1]-xlist[i])/2*tempsum;
    }

    return sqrt(sum);
}

T error_inf(const vector<T> &uh, const vector<T> &xlist, T h1, T h2, T ep, T (*u)(T ep, T x), matrix &plots1, matrix &plots2)
{
    index len = xlist.size() - 1;
    index n = len / 2;
    index m = ERRORCOUNT;
    vector<T> x_values(m * len, 0); //每个cell取9个十等分点，不含两个端点
    vector<T> uh_values(m * len, 0);
    vector<T> u_values(m * len, 0);

    plots1 = newMatrix(m * len, 2);
    plots2 = newMatrix(m * len, 2);

    T cell_length;

    for (index i = 0; i < len; i++) {
        if (i < n) {
            cell_length = h1;
        }
        else {
            cell_length = h2;
        }
        for (index j = 0; j < m; j++) {
            x_values[i * m + j] = xlist[i] + j * cell_length / m;
        }
    }

    T maxinf = 0;
    T temp;
    for (index i = 0; i < m * len; i++) {
        u_values[i] = u(ep, x_values[i]);
        uh_values[i] = evaluate(uh, xlist, x_values[i]);
        temp = fabs(u_values[i] - uh_values[i]);
        maxinf = (temp > maxinf) ? temp : maxinf;
        plots1[i][0] = x_values[i];
        plots1[i][1] = uh_values[i];
        plots2[i][0] = x_values[i];
        plots2[i][1] = u_values[i];
    }

    return maxinf;
}

void maintest(index n_begin, T ep)
{
    index round = ROUNDMAX;
    T xmid, h1, h2, h;
    index n = n_begin;

    vector<T> e1(round, 0);
    vector<T> e2(round, 0);
    matrix plot1 = newMatrix(2 * n_begin, 2);
    matrix plot2 = newMatrix(2 * n_begin, 2);

    for (index round_i = 0; round_i < round; round_i++) {
        xmid = 1 - 2 * ep * log(n);
        printf("xmid=%.12f,", xmid);

        h1 = xmid / n;
        h2 = (1 - xmid) / n;
        h = 1.0 / (2 * n);

        vector<T> xlist_1(2 * n + 1, 0);
        for (index i = 0; i < 2 * n + 1; i++) {
            xlist_1[i] = i * h;
        }
        vector<T> uh_1 = fun_main(n, ep, h, h, xlist_1, test_f);
#ifdef ERRORINF
        e1[round_i] = error_inf(uh_1, xlist_1, h, h, ep, test_u, plot1, plot2);
#endif
#ifndef ERRORINF
        e1[round_i] = error_L2(uh_1, xlist_1, h, h, ep, test_u, plot1, plot2);
#endif
        if (xmid > 0 && xmid < 1) {
            vector<T> xlist_2(2 * n + 1, 0);
            for (index i = 0; i <= n; i++) {
                xlist_2[i] = i * h1;
            }
            for (index i = n + 1; i < 2 * n + 1; i++) {
                xlist_2[i] = xlist_2[n] + (i - n) * h2;
            }
            vector<T> uh_2 = fun_main(n, ep, h1, h2, xlist_2, test_f);
#ifdef ERRORINF
            e2[round_i] = error_inf(uh_2, xlist_2, h1, h2, ep, test_u, plot1, plot2);
#endif
#ifndef ERRORINF
            e2[round_i] = error_L2(uh_2, xlist_2, h1, h2, ep, test_u, plot1, plot2);
#endif
        }
        printf("n=%d\te1=%.12f,e2=%.12f\n", n, e1[round_i], e2[round_i]);
        n = n * 2;
    }

    vector<T> o1 = ordertest(e1);
    vector<T> o2 = ordertest(e2);

    readVector(e1,reading_flag_12f);
    readVector(e2,reading_flag_12f);
    readVector(o1);
    readVector(o2);
    return;
}

void test1(index n, T ep)
{
    T h = 1.0 / (2 * n);
    vector<T> xlist_1(2 * n + 1, 0);
    matrix plot1 = newMatrix(10, 2);
    matrix plot2 = newMatrix(10, 2);
    for (index i = 0; i < 2 * n + 1; i++) {
        xlist_1[i] = i * h;
    }

    printf("x列表\n");
    readVector(xlist_1);
    vector<T> uh = fun_main(n, ep, h, h, xlist_1, test_f);
    printf("uh系数\n");
    readVector(uh);
    T e1 = error_L2(uh, xlist_1, h, h, ep, test_u, plot1, plot2);
    printf("n=%d\te1=%.12f\n", n, e1);
#ifdef PLOT
    printf("temp1=");
    readMatrix(plot1, reading_flag_mma);
    printf(";\n");
    printf("temp2=");
    readMatrix(plot2, reading_flag_mma);
    printf(";\n");
#endif
    return;
}

void test2(index n, T ep)
{
    T xmid = 1.0 - 2 * ep * log(n);
    T h1 = xmid / n;
    T h2 = (1 - xmid) / n;
    matrix plot1 = newMatrix(10, 2);
    matrix plot2 = newMatrix(10, 2);
    vector<T> xlist_2(2 * n + 1, 0);
    for (index i = 0; i <= n; i++) {
        xlist_2[i] = i * h1;
    }
    for (index i = n + 1; i < 2 * n + 1; i++) {
        xlist_2[i] = xlist_2[n] + (i - n) * h2;
    }

    printf("x列表\n");
    readVector(xlist_2);
    vector<T> uh = fun_main(n, ep, h1, h2, xlist_2, test_f);
    printf("uh系数\n");
    readVector(uh);
    T e1 = error_inf(uh, xlist_2, h1, h2, ep, test_u, plot1, plot2);
    printf("n=%d\te1=%.12f\n", n, e1);
#ifdef PLOT
    printf("temp1=");
    readMatrix(plot1, reading_flag_mma);
    printf(";\n");
    printf("temp2=");
    readMatrix(plot2, reading_flag_mma);
    printf(";\n");
#endif
    return;
}

int main()
{
    index n = N_BEGIN;
    T ep = EP;

    printf("ep=%.12f\n", ep);
    maintest(n, ep);
    //test1(n, ep);

    return 0;
}
