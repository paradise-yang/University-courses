//#define PLOT
//#define KDSHOW
//#define ERRORINF
#define ERRORCOUNT 8
#define ROUNDMAX 10
#define N_BEGIN 160
#define EP 1e-7