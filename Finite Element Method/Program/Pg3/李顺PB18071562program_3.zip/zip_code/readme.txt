a.cpp 主要源代码，包括main函数

flag.h 通过几个宏定义控制一些选项：
包括是否详细输出点列(作图)，是否输出矩阵K和右端项检查
用无穷范数还是L2范数计算误差
epsilon大小
n起始大小，加倍轮数。

MyHead.h MyMatrixBase.h 头文件，libmar.a 静态库，包括矩阵和向量的加减法重载等。

编译需要加上libmar.a，例如g++ a.cpp libmar.a -o a.exe;./a.exe