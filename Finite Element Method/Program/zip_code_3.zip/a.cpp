#include <cmath>
#include <iostream>
#include <stdio.h>
#include <vector>

#include "base_p.cpp"       //基函数定义
#include "information2.cpp" //c d f u 定义

//包括追赶法求解三对角矩阵，以及一些矩阵输出相关的函数，运算符重载等
#include "new_matrix.cpp"

//gauss消元法，还有配套的一些数值代数课上写的cpp文件
#include "new_gauss_kernel.cpp"

T gauss_integrate(T (*f)(T x), T (*p)(T x), T h, T x_center)
{
    //3个点的gauss积分公式
    vector<T> points = {-sqrt(0.6), 0, sqrt(0.6)};
    vector<T> weights = {5.0 / 9, 8.0 / 9, 5.0 / 9};
    index gauss_k = 3;

    T s = 0;
    for (index i = 0; i < gauss_k; i++) {
        s = s + weights[i] * (f(x_center + h / 2 * points[i])) * p(points[i]);
    }
    s = s * h / 2;
    return s;
}

T gauss_integrate(T (*f)(T x), T (*p1)(T x), T (*p2)(T x), T h, T x_center)
{
    //3个点的gauss积分公式
    vector<T> points = {-sqrt(0.6), 0, sqrt(0.6)};
    vector<T> weights = {5.0 / 9, 8.0 / 9, 5.0 / 9};
    index gauss_k = 3;

    T s = 0;
    for (index i = 0; i < gauss_k; i++) {
        s = s + weights[i] * (f(x_center + h / 2 * points[i])) * p1(points[i]) * p2(points[i]);
    }
    s = s * h / 2;
    return s;
}

//k=1获得矩阵K
matrix setmatrix_P1(index n, T (*d_fun)(T x), T (*c_fun)(T x))
{

    matrix A = newMatrix(n - 1, n - 1, 0);
    T h = 1.0 / n, coeff = 4.0 / (h * h);
    T xcenter = h / 2;
    T temp1 = 0, temp2 = 0;
    for (index i = 0; i < n - 1; i++) {
        //填充A[i][i]
        temp1 = gauss_integrate(c_fun, p0_left, p0_left, h, xcenter) + gauss_integrate(c_fun, p0_right, p0_right, h, xcenter + h);
        temp2 = gauss_integrate(d_fun, p0_left_x, p0_left_x, h, xcenter) + gauss_integrate(d_fun, p0_right_x, p0_right_x, h, xcenter + h);
        A[i][i] = temp1 + coeff * temp2;
        xcenter = xcenter + h;
    }
    xcenter = 3 * h / 2.0;
    for (index i = 1; i < n - 1; i++) {
        //填充A[i-1][i]
        temp1 = gauss_integrate(c_fun, p0_right, p0_left, h, xcenter);
        temp2 = gauss_integrate(d_fun, p0_right_x, p0_left_x, h, xcenter);
        A[i - 1][i] = temp1 + coeff * temp2;
        xcenter = xcenter + h;
    }

    xcenter = 3 * h / 2.0;
    for (index i = 1; i < n - 1; i++) {
        //填充A[i][i+1]
        temp1 = gauss_integrate(c_fun, p0_right, p0_left, h, xcenter);
        temp2 = gauss_integrate(d_fun, p0_right_x, p0_left_x, h, xcenter);
        A[i][i - 1] = temp1 + coeff * temp2;
        xcenter = xcenter + h;
    }

    //readMatrix(A);
    return A;
}


//k=2获得矩阵K
matrix setmatrix_P2(index n, T (*d_fun)(T x), T (*c_fun)(T x))
{
    matrix A = newMatrix(2 * n - 1, 2 * n - 1, 0);
    T h = 1.0 / n, coeff = 4.0 / (h * h);
    T xcenter;
    T temp1, temp2;
    xcenter = h / 2;
    //主对角线，分两类
    for (index i = 0; i < 2 * n - 1; i = i + 2) {
        //两个分数指标基函数，指标相同A[i][i]
        temp1 = gauss_integrate(c_fun, p2, p2, h, xcenter);
        temp2 = gauss_integrate(d_fun, p2_x, p2_x, h, xcenter);
        A[i][i] = temp1 + coeff * temp2;
        xcenter = xcenter + h;
    }

    xcenter = h / 2;
    for (index i = 1; i < 2 * n - 1; i = i + 2) {
        //两个整指标基函数，指标相同A[i][i]
        temp1 = gauss_integrate(c_fun, p1_left, p1_left, h, xcenter) + gauss_integrate(c_fun, p1_right, p1_right, h, xcenter + h);
        temp2 = gauss_integrate(d_fun, p1_left_x, p1_left_x, h, xcenter) + gauss_integrate(d_fun, p1_right_x, p1_right_x, h, xcenter + h);
        A[i][i] = temp1 + coeff * temp2;
        xcenter = xcenter + h;
    }

    //对角线上，A[i][i+1]分为两类
    xcenter = h / 2;
    for (index i = 1; i < 2 * n - 1; i = i + 2) {
        //错位的，一个分数指标的基函数和右边相邻的整数指标基函数A[i-1][i]
        temp1 = gauss_integrate(c_fun, p2, p1_left, h, xcenter);
        temp2 = gauss_integrate(d_fun, p2_x, p1_left_x, h, xcenter);
        A[i - 1][i] = temp1 + coeff * temp2;
        A[i][i - 1] = A[i - 1][i];
        xcenter = xcenter + h;
    }
    xcenter = 3 * h / 2;
    for (index i = 2; i < 2 * n - 1; i = i + 2) {
        //错位的，一个整数基和右边的分数基函数A[i][i+1]
        temp1 = gauss_integrate(c_fun, p1_right, p2, h, xcenter);
        temp2 = gauss_integrate(d_fun, p1_right_x, p2_x, h, xcenter);
        A[i - 1][i] = temp1 + coeff * temp2;
        A[i][i - 1] = A[i - 1][i];
        xcenter = xcenter + h;
    }

    //A[i][i+2]
    xcenter = 3 * h / 2.0;
    for (index i = 3; i < 2 * n - 1; i = i + 2) {
        //错位的，两个相邻的整数指标基函数A[i-2][i]
        temp1 = gauss_integrate(c_fun, p1_right, p1_left, h, xcenter);
        temp2 = gauss_integrate(d_fun, p1_right_x, p1_left_x, h, xcenter);
        A[i - 2][i] = temp1 + coeff * temp2;
        A[i][i - 2] = A[i - 2][i];
        xcenter = xcenter + h;
    }

    //readMatrix(A);
    return A;
}



vector<T> fun_P1(index nx, T (*f_fun)(T x), T (*d_fun)(T x), T (*c_fun)(T x))
{
    T h = 1.0 / nx;
    vector<T> f_times_p0_left(nx, 0);
    vector<T> f_times_p0_right(nx, 0);
    T x_center = h / 2;
    for (index i = 0; i < nx; i++) {
        f_times_p0_left[i] = gauss_integrate(f_fun, p0_left, h, x_center);
        f_times_p0_right[i] = gauss_integrate(f_fun, p0_right, h, x_center);
        x_center += h;
    }

    vector<T> d(nx - 1, 0);
    for (index i = 0; i < nx - 1; i++) {
        d[i] = f_times_p0_left[i] + f_times_p0_right[i + 1];
    }
    matrix A = setmatrix_P1(nx, d_fun, c_fun); //矩阵数乘，已经重载定义过
    vector<T> uh = thomas(A, d);               //追赶法求解
    return uh;
}

vector<T> fun_P2(index nx, T (*f_fun)(T x), T (*d_fun)(T x), T (*c_fun)(T x))
{
    T h = 1.0 / nx;
    vector<T> f_times_p1_left(nx, 0);
    vector<T> f_times_p1_right(nx, 0);
    vector<T> f_times_p2(nx, 0);
    T x_center = h / 2;
    for (index i = 0; i < nx; i++) {
        f_times_p1_left[i] = gauss_integrate(f_fun, p1_left, h, x_center);
        f_times_p1_right[i] = gauss_integrate(f_fun, p1_right, h, x_center);
        f_times_p2[i] = gauss_integrate(f_fun, p2, h, x_center);
        x_center += h;
    }

    vector<T> d(2 * nx - 1, 0);

    for (index i = 0; i < nx; i++) {
        //f*p2
        d[2 * i] = f_times_p2[i];
    }
    for (index i = 1; i < 2 * nx - 1; i = i + 2) {
        //f*p1
        index j = (i - 1) / 2;
        d[i] = f_times_p1_left[j] + f_times_p1_right[j + 1];
    }

    matrix A = setmatrix_P2(nx, d_fun, c_fun);
    vector<T> uh = Gauss_Elimination(A, d, quiet).second; //gauss消元法求解
    return uh;
}


T error_P1(T (*u)(T x), const vector<T> &uh, matrix &diff_list, index error_flag, index plot_flag)
{
    index nx = uh.size() + 1;
    T h = 1.0 / nx;
    T error_L1 = 0, error_inf = 0, error_L2 = 0;

    T x_left = h / 3, x_right = h * 2 / 3; //每个小区间取三等分点计算误差
    T diff_left = 0, diff_right = 0;
    T uh_left = 0, uh_right = 0;
    T temp = 0;
    vector<T> x_values(2 * nx, 0), uh_values(2 * nx, 0), u_values(2 * nx, 0);

    //第一个区间
    uh_left = 1.0 / 3 * uh[0];
    uh_right = 2.0 / 3 * uh[0];
    //记录散点
    x_values[0] = x_left;
    uh_values[0] = uh_left;
    u_values[0] = u(x_left);
    x_values[1] = x_right;
    uh_values[1] = uh_right;
    u_values[1] = u(x_right);
    //计算误差
    diff_left = myabs(u(x_left) - uh_left);
    diff_right = myabs(u(x_right) - uh_right);
    error_L1 = error_L1 + diff_left + diff_right;
    error_L2 = error_L2 + diff_left * diff_left + diff_right * diff_right;
    temp = (diff_right > diff_left) ? diff_right : diff_left;
    error_inf = (temp > error_inf) ? temp : error_inf;
    //中间区间
    for (index i = 1; i < nx - 1; i++) {
        x_left += h;
        x_right += h;
        uh_left = 2.0 / 3 * uh[i - 1] + 1.0 / 3 * uh[i];
        uh_right = 1.0 / 3 * uh[i - 1] + 2.0 / 3 * uh[i];
        //记录散点
        x_values[2 * i] = x_left;
        uh_values[2 * i] = uh_left;
        u_values[2 * i] = u(x_left);
        x_values[2 * i + 1] = x_right;
        uh_values[2 * i + 1] = uh_right;
        u_values[2 * i + 1] = u(x_right);
        //计算误差
        diff_left = myabs(u(x_left) - uh_left);
        diff_right = myabs(u(x_right) - uh_right);
        error_L1 = error_L1 + diff_left + diff_right;
        error_L2 = error_L2 + diff_left * diff_left + diff_right * diff_right;
        temp = (diff_right > diff_left) ? diff_right : diff_left;
        error_inf = (temp > error_inf) ? temp : error_inf;
    }
    //最后一个区间
    x_left += h;
    x_right += h;
    uh_left = 2.0 / 3 * uh[nx - 2];
    uh_right = 1.0 / 3 * uh[nx - 2];
    //记录散点
    x_values[2 * nx - 2] = x_left;
    uh_values[2 * nx - 2] = uh_left;
    u_values[2 * nx - 2] = u(x_left);
    x_values[2 * nx - 1] = x_right;
    uh_values[2 * nx - 1] = uh_right;
    u_values[2 * nx - 1] = u(x_right);
    //计算误差
    diff_left = myabs(u(x_left) - uh_left);
    diff_right = myabs(u(x_right) - uh_right);
    error_L1 = error_L1 + diff_left + diff_right;
    error_L2 = error_L2 + diff_left * diff_left + diff_right * diff_right;
    temp = (diff_right > diff_left) ? diff_right : diff_left;
    error_inf = (temp > error_inf) ? temp : error_inf;

    if (plot_flag == 1) {
        printf("--------\n");
        printf("title=\"nx = %d,k = %d new\"\n", nx, 1);
        printf("variables=x,u,v\n");
        printf("zone t=\"numerical solution\"\n");
        printf("i=%d,j=1,f=point\n", nx * 2);
        for (index k = 0; k < 2 * nx; k++) {
            printf("%f %f %f\n", x_values[k], u_values[k], uh_values[k]);
        }
        printf("--------\n");
    }
    if (plot_flag == 2) {
        diff_list = newMatrix(2 * nx, 2);
        for (index k = 0; k < 2 * nx; k++) {
            diff_list[k][0] = x_values[k];
            diff_list[k][1] = u_values[k] - uh_values[k];
        }
    }


    error_L1 = error_L1 / (2.0 * nx);
    error_L2 = sqrt(error_L2 / (2.0 * nx));
    if (error_flag == 0)
        return error_L1;
    else if (error_flag == 1)
        return error_inf;
    else
        return error_L2;
}

T error_P2(T (*u)(T x), const vector<T> &uh, matrix &diff_list, index error_flag, index plot_flag)
{
    index length = uh.size();
    index nx = (length + 1) / 2;
    T h = 1.0 / nx;
    T error_L1 = 0, error_inf = 0, error_L2 = 0;

    T x_left = h / 3, x_right = h * 2.0 / 3; //每个小区间取三等分点计算误差
    T diff_left = 0, diff_right = 0;
    T uh_left = 0, uh_right = 0;
    T temp = 0;
    vector<T> x_values(2 * nx, 0), uh_values(2 * nx, 0), u_values(2 * nx, 0);

    //第一个区间
    uh_left = 8.0 / 9 * uh[0] - 1.0 / 9 * uh[1];
    uh_right = 8.0 / 9 * uh[0] + 2.0 / 9 * uh[1];
    //记录散点
    x_values[0] = x_left;
    uh_values[0] = uh_left;
    u_values[0] = u(x_left);
    x_values[1] = x_right;
    uh_values[1] = uh_right;
    u_values[1] = u(x_right);
    //计算误差
    diff_left = myabs(u(x_left) - uh_left);
    diff_right = myabs(u(x_right) - uh_right);
    error_L1 = error_L1 + diff_left + diff_right;
    error_L2 = error_L2 + diff_left * diff_left + diff_right * diff_right;
    temp = (diff_right > diff_left) ? diff_right : diff_left;
    error_inf = (temp > error_inf) ? temp : error_inf;
    //中间区间
    for (index i = 1; i < nx - 1; i++) {
        x_left += h;
        x_right += h;
        uh_left = 8.0 / 9 * uh[2 * i] + 2.0 / 9 * uh[2 * i - 1] - 1.0 / 9 * uh[2 * i + 1];
        uh_right = 8.0 / 9 * uh[2 * i] - 1.0 / 9 * uh[2 * i - 1] + 2.0 / 9 * uh[2 * i + 1];
        //记录散点
        x_values[2 * i] = x_left;
        uh_values[2 * i] = uh_left;
        u_values[2 * i] = u(x_left);
        x_values[2 * i + 1] = x_right;
        uh_values[2 * i + 1] = uh_right;
        u_values[2 * i + 1] = u(x_right);
        //计算误差
        diff_left = myabs(u(x_left) - uh_left);
        diff_right = myabs(u(x_right) - uh_right);
        error_L1 = error_L1 + diff_left + diff_right;
        error_L2 = error_L2 + diff_left * diff_left + diff_right * diff_right;
        temp = (diff_right > diff_left) ? diff_right : diff_left;
        error_inf = (temp > error_inf) ? temp : error_inf;
    }
    //最后一个区间
    x_left += h;
    x_right += h;
    uh_left = 8.0 / 9 * uh[2 * nx - 2] + 2.0 / 9 * uh[2 * nx - 3];
    uh_right = 8.0 / 9 * uh[2 * nx - 2] - 1.0 / 9 * uh[2 * nx - 3];
    //记录散点
    x_values[2 * nx - 2] = x_left;
    uh_values[2 * nx - 2] = uh_left;
    u_values[2 * nx - 2] = u(x_left);
    x_values[2 * nx - 1] = x_right;
    uh_values[2 * nx - 1] = uh_right;
    u_values[2 * nx - 1] = u(x_right);
    //计算误差
    diff_left = myabs(u(x_left) - uh_left);
    diff_right = myabs(u(x_right) - uh_right);
    error_L1 = error_L1 + diff_left + diff_right;
    error_L2 = error_L2 + diff_left * diff_left + diff_right * diff_right;
    temp = (diff_right > diff_left) ? diff_right : diff_left;
    error_inf = (temp > error_inf) ? temp : error_inf;

    if (plot_flag == 1) {
        printf("--------\n");
        printf("title=\"nx = %d,k = %d new\"\n", nx, 2);
        printf("variables=x,u,v\n");
        printf("zone t=\"numerical solution\"\n");
        printf("i=%d,j=1,f=point\n", nx * 2);
        for (index k = 0; k < 2 * nx; k++) {
            printf("%f %f %f\n", x_values[k], u_values[k], uh_values[k]);
        }
        printf("--------\n");
    }
    if (plot_flag == 2) {
        diff_list = newMatrix(2 * nx, 2);
        for (index k = 0; k < 2 * nx; k++) {
            diff_list[k][0] = x_values[k];
            diff_list[k][1] = u_values[k] - uh_values[k];
        }
    }

    error_L1 = error_L1 / (2.0 * nx);
    error_L2 = sqrt(error_L2 / (2.0 * nx));
    if (error_flag == 0)
        return error_L1;
    else if (error_flag == 1)
        return error_inf;
    else
        return error_L2;
}



int test_P1(index nx, index round, T (*f_fun)(T x), T (*d_fun)(T x), T (*c_fun)(T x), T (*u)(T x), index plot_flag)
{
    vector<T> uh(nx);
    vector<T> error_L1(round, 0), error_L2(round, 0), error_inf(round, 0);
    vector<T> order_L1(round, 0), order_L2(round, 0), order_inf(round, 0);
    matrix diff_1 = newMatrix(2 * nx, 2), diff_2 = diff_1, diff_3 = diff_1;

    for (index i = 0; i < round; i++) {
        uh = fun_P1(nx, f_fun, d_fun, c_fun);
        //readVector_f2(uh);
        error_L1[i] = error_P1(u, uh, diff_1, 0, plot_flag);
        error_L2[i] = error_P1(u, uh, diff_2, 1, 0);
        error_inf[i] = error_P1(u, uh, diff_3, 2, 0);
        //printf("nx = %d error_L1 = %f error_inf = %f\n", nx, error_L1, error_inf);
        if (i != 0) {
            order_L1[i] = log(error_L1[i - 1] / error_L1[i]) / log(2.0);
            order_L2[i] = log(error_L2[i - 1] / error_L2[i]) / log(2.0);
            order_inf[i] = log(error_inf[i - 1] / error_inf[i]) / log(2.0);
        }
        if (plot_flag == 2) {
            printf("k=1,nx=%d\n", nx);
            readMatrix_plot(diff_1);
        }
        nx = nx * 2;
    }
    if (plot_flag == 0) { //不作图则输出表格
        printf("$L^1$ error:");
        readVector_e2(error_L1);
        printf("order:");
        readVector_f2(order_L1);
        printf("$L^2$ error:");
        readVector_e2(error_L2);
        printf("order:");
        readVector_f2(order_L2);
        printf("$L^\\infty$ error:");
        readVector_e2(error_inf);
        printf("order:");
        readVector_f2(order_inf);
    }
    return 0;
}

int test_P2(index nx, index round, T (*f_fun)(T x), T (*d_fun)(T x), T (*c_fun)(T x), T (*u)(T x), index plot_flag)
{
    vector<T> uh(nx);
    vector<T> error_L1(round, 0), error_L2(round, 0), error_inf(round, 0);
    vector<T> order_L1(round, 0), order_L2(round, 0), order_inf(round, 0);
    matrix diff_1 = newMatrix(2 * nx, 2), diff_2 = diff_1, diff_3 = diff_1;

    for (index i = 0; i < round; i++) {
        uh = fun_P2(nx, f_fun, d_fun, c_fun);
        //readVector_f2(uh);
        error_L1[i] = error_P2(u, uh, diff_1, 0, plot_flag);
        error_L2[i] = error_P2(u, uh, diff_2, 1, 0);
        error_inf[i] = error_P2(u, uh, diff_3, 2, 0);
        //printf("nx = %d error_L1 = %f error_inf = %f\n", nx, error_L1, error_inf);
        if (i != 0) {
            order_L1[i] = log(error_L1[i - 1] / error_L1[i]) / log(2.0);
            order_L2[i] = log(error_L2[i - 1] / error_L2[i]) / log(2.0);
            order_inf[i] = log(error_inf[i - 1] / error_inf[i]) / log(2.0);
        }
        if (plot_flag == 2) {
            printf("k=2,nx=%d\n", nx);
            readMatrix_plot(diff_1);
        }
        nx = nx * 2;
    }
    if (plot_flag == 0) { //不作图则输出表格
        printf("$L^1$ error:");
        readVector_e2(error_L1);
        printf("order:");
        readVector_f2(order_L1);
        printf("$L^2$ error:");
        readVector_e2(error_L2);
        printf("order:");
        readVector_f2(order_L2);
        printf("$L^\\infty$ error:");
        readVector_e2(error_inf);
        printf("order:");
        readVector_f2(order_inf);
    }
    return 0;
}

int main()
{
    index nx = 10;       //起始的n
    index round = 4;     //加密次数
    index plot_flag = 0; 		//作图则把plot_flag改为1，不再输出表格，而是每次输出点列，可以导出作图
	//误差分布则改为2
    test_P1(nx, round, test_f, test_d, test_c, test_u, plot_flag);
    printf("\n");
    test_P2(nx, round, test_f, test_d, test_c, test_u, plot_flag);
    return 0;
}