#include <cmath>
#include <iostream>
#include <stdio.h>
#include <vector>

using namespace std;

typedef double T;
typedef unsigned index;
typedef vector<vector<T>> matrix;



//P1基函数，左右两部分都转化到[-1,1]区间上
T p0_left(T x)
{
    return (1.0 + x) / 2;
}
T p0_left_x(T x)
{
    return 1.0 / 2;
}

T p0_right(T x)
{
    return (1.0 - x) / 2;
}
T p0_right_x(T x)
{
    return -1.0 / 2;
}

//P2的一类基函数，分为左右两部分
T p1_left(T x)
{
    return x * (x + 1.0) / 2;
}
T p1_left_x(T x)
{
    return (2 * x + 1.0) / 2;
}

T p1_right(T x)
{
    return x * (x - 1.0) / 2;
}
T p1_right_x(T x)
{
    return (2 * x - 1.0) / 2;
}

//P2的第二类基函数
T p2(T x)
{
    return 1.0 - x * x;
}
T p2_x(T x)
{
    return -2 * x;
}