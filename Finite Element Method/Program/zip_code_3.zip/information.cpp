#include <cmath>
#include <iostream>
#include <stdio.h>
#include <vector>

using namespace std;
typedef double T;
typedef unsigned index;
typedef vector<vector<T>> matrix;

//右端项f
T test_f(T x)
{
    return -2 * cos(x) + (x - 1) * sin(x);
}

T test_d(T x)
{
    return 1.0;
}

T test_c(T x)
{
    return 0;
}

//精确解u
T test_u(T x)
{
    return (x - 1) * sin(x);
}