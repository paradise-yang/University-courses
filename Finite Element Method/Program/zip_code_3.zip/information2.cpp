#include <cmath>
#include <iostream>
#include <stdio.h>
#include <vector>

using namespace std;
typedef double T;
typedef unsigned index;
typedef vector<vector<T>> matrix;

//右端项f
T test_f(T x)
{
    return (x*x+1)*(x-1)*x-2*(sin(x)+2)-(2*x-1)*cos(x);
}

T test_d(T x)
{
    return 2 + sin(x);
}

T test_c(T x)
{
    return x * x + 1;
}

//精确解u
T test_u(T x)
{
    return (x - 1) * x;
}