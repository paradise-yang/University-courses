//整理一次完成
#ifndef MY_GAUSS_KERNEL
#define MY_GAUSS_KERNEL
#include "new_head.h"
#include "new_matrix_base.cpp"
#include "new_matrix_operator.cpp"

//存储Gauss全主元消去法的结果,用于快速重复求解
typedef struct Gauss_prepared_cell {
    Status s;
    matrix A;
    vector<T> u;
    vector<T> v;
} Gauss_prepared_cell;

//下三角方程求解,可能奇异退出
cell Gauss_L(const matrix &L, const vector<T> &constb)
{
    if (!Check(L, constb)) {
        cout << "Gauss_L:矩阵异常,或矩阵与向量不兼容,失败退出\n";
        return cell(ERROR, constb);
    }
    vector<T> b(constb);
    index n = L.size();
    for (index i = 0; i < n; i++) {
        if (!L[i][i]) {
            cout << "Gauss_L:遇到奇异,求解失败退出\n";
            return cell(ERROR, b);
        }
        else
            b[i] = b[i] / L[i][i];
        for (index j = i + 1; j < n; j++)
            b[j] = b[j] - b[i] * L[j][i];
    }
    return cell(OK, b);
}

//单位下三角方程求解,不会奇异退出
cell Gauss_L_I(const matrix &L, const vector<T> &constb)
{
    if (!Check(L, constb)) {
        cout << "Gauss_L_I:矩阵异常,或矩阵与向量不兼容,失败退出\n";
        return cell(ERROR, constb);
    }
    vector<T> b(constb);
    index n = L.size();
    for (index i = 0; i < n; i++) {
        for (index j = i + 1; j < n; j++)
            b[j] = b[j] - b[i] * L[j][i];
    }
    return cell(OK, b);
}

//上三角方程求解,可能奇异退出
cell Gauss_U(const matrix &U, const vector<T> &consty)
{
    if (!Check(U, consty)) {
        cout << "Gauss_U:矩阵异常,或矩阵与向量不兼容,失败退出\n";
        return cell(ERROR, consty);
    }
    vector<T> y(consty);
    index n = U.size();
    for (index j = n - 1; j > 0; j--) {
        if (!U[j][j]) {
            cout << "Gauss_U:遇到奇异,求解失败退出\n";
            return cell(ERROR, y);
        }
        else
            y[j] = y[j] / U[j][j];
        for (index k = 0; k < j; k++)
            y[k] = y[k] - y[j] * U[k][j];
    }
    if (!U[0][0]) {
        cout << "Gauss_U:遇到奇异,求解失败退出\n";
        return cell(ERROR, y);
    }
    else {
        y[0] = y[0] / U[0][0];
        return cell(OK, y);
    }
}

//LU分解,就地修改A并且存储,可能奇异失败
Status Gauss_LU(matrix &A)
{
    //就地修改A矩阵进行LU分解
    if (!Check(A) || A.size() != A[0].size()) {
        cout << "Gauss_LU:矩阵尺寸异常或者非方阵,无法LU分解,失败退出\n";
        return ERROR;
    }
    index n = A.size();
    for (index k = 0; k < n; k++) {
        if (!A[k][k]) {
            cout << "Gauss_LU:遇到奇异主元为0,无法LU分解,失败退出\n";
            return ERROR;
        }
        for (index j = k + 1; j < n; j++)
            A[j][k] = A[j][k] / A[k][k];
        for (index i1 = k + 1; i1 < n; i1++)
            for (index i2 = k + 1; i2 < n; i2++)
                A[i1][i2] -= A[i1][k] * A[k][i2];
    }
    return OK;
}

//LU分解的分开存储版本,可能奇异失败
//A就地存储上三角并且清理下三角,单位下三角分离存储在B中
Status LU_Expand(matrix &A, matrix &B)
{
    if (!Check(A) || A.size() != A[0].size()) {
        cout << "LU_Expand:矩阵尺寸异常或者非方阵,无法LU分解,失败退出\n";
        return ERROR;
    }
    index n = A.size();
    for (index k = 0; k < n; k++) {
        if (!A[k][k]) {
            cout << "LU_Expand:遇到奇异主元为0,无法LU分解,失败退出\n";
            return ERROR;
        }
        for (index j = k + 1; j < n; j++)
            A[j][k] = A[j][k] / A[k][k];
        for (index i1 = k + 1; i1 < n; i1++)
            for (index i2 = k + 1; i2 < n; i2++)
                A[i1][i2] -= A[i1][k] * A[k][i2];
    }
    B = Init_Identity_matrix(n, 1);
    //清理A下三角,转存到B中
    for (index k = 1; k < n; k++) {
        for (index j = 0; j < k; j++) {
            B[k][j] = A[k][j];
            A[k][j] = 0;
        }
    }
    return OK;
}

//测试用函数,被全主元列主元的求解函数调用,将被剥离
Status Recover_LU(const matrix &A)
{
    if (!Check(A) || A.size() != A[0].size()) {
        cout << "Recover_LU:试图对非方阵进行LU分解的恢复,失败退出\n";
        return ERROR;
    }
    index n = A.size(), min;
    matrix B(n);
    T c;
    for (index i = 0; i < n; i++)
        for (index j = 0; j < n; j++) {
            c = 0;
            min = (i < j) ? i : j;
            for (index k = 0; k < min; k++)
                c += A[i][k] * A[k][j];
            c += (i > j) ? (A[i][j] * A[j][j]) : (A[i][j]);
            B[i].push_back(c);
        }
    cout << "Recover_LU:LU恢复的结果\n";
    PrintMatrix(B); //自动打印矩阵B
    return OK;
}

//不选主元的高斯求解函数
cell Gauss_Elimination(const matrix &constA, const vector<T> &constb, const enum pattern mode = normal)
{
    if (!Check(constA, constb)) {
        cout << "Gauss_Elimination:矩阵尺寸异常,或矩阵与向量不兼容,失败退出\n";
        return cell(ERROR, constb);
    }
    index n = constb.size();
    matrix A(constA);
    vector<T> b(constb), b2(b);
    if (mode != quiet)
        cout << "Gauss_Elimination:进入\n";
    if (!Gauss_LU(A)) { //已经就地修改了A
        cout << "Gauss_Elimination:遇到奇异,求解失败退出\n";
        return cell(ERROR, b);
    }
    b = Gauss_L_I(A, b).second;
    cell temp = Gauss_U(A, b);
    if (temp.first != OK) {
        cout << "Gauss_Elimination:遇到奇异,求解失败退出\n";
        return temp;
    }
    else
        b = temp.second;
    if (mode == normal || mode == detail) {
        cout << "Gauss_Elimination:解向量\n";
        PrintVector(b);
        if (mode == detail) {
            for (index k = 0; k < n; k++)
                for (index j = 0; j < n; j++)
                    b2[k] = b2[k] - constA[k][j] * b[j];
            T delta = Infinity_norm(b2);
            cout << "Gauss_Elimination:解向量的误差b-Ax的无穷范数=" << delta << endl;
        }
        cout << "Gauss_Elimination:退出\n";
    }
    return cell(OK, b);
}

//全主元的高斯求解函数
cell Gauss_Elimination_Full(const matrix &constA, const vector<T> &constb, const enum pattern mode = normal)
{
    if (!Check(constA, constb)) {
        cout << "Gauss_Elimination_Full:矩阵尺寸异常,或矩阵与向量不兼容,失败退出\n";
        return cell(ERROR, constb);
    }
    matrix A(constA);
    vector<T> b(constb), b2(constb);
    index n = b.size(), i, p, q, temp_i; //n是尺寸，i用于向量操作，p,q寻找主元，temp_i用于u,v的一些记录交换
    T Max, temp_T;                       //Max记录最大元，temp_T用于交换列
    vector<T> u, v, temp_vector;         //u,v用于记录行列变换，temp_vector用于交换行
    for (i = 0; i < n; i++) {
        u.push_back(i); //u,v标记向量初始化
        v.push_back(i);
    }
    if (mode != quiet)
        cout << "Gauss_Elimination_Full:进入\n";
    //PAQ = LU，其中P，Q分别由u，v记录
    for (index k = 0; k < n - 1; k++) {
        //找最大元指标p,q
        Max = abs(A[k][k]);
        p = q = k;
        for (index p1 = k; p1 < n; p1++) {
            for (index q1 = k; q1 < n; q1++) {
                if (abs(A[p1][q1]) > Max) {
                    Max = abs(A[p1][q1]);
                    p = p1;
                    q = q1;
                }
            }
        }
        if (mode == detail) {
            cout << "第" << k << "次调整前\n";
            PrintMatrix(A);
            cout << "第" << k << "次找到模最大元" << Max << "在 (" << p << "," << q << ")位置\n";
        }
        //交换k,p行
        temp_vector = A[k];
        A[k] = A[p];
        A[p] = temp_vector;
        //交换k,q列
        for (i = 0; i < n; i++) {
            temp_T = A[i][k];
            A[i][k] = A[i][q];
            A[i][q] = temp_T;
        }
        //记录交换行为，u记录行变换，v记录列变换
        temp_i = u[k];
        u[k] = u[p];
        u[p] = temp_i;
        temp_i = v[k];
        v[k] = v[q];
        v[q] = temp_i;
        //主体部分，如果主元非退化
        if (A[k][k]) {
            for (index j = k + 1; j < n; j++)
                A[j][k] = A[j][k] / A[k][k];
            for (index i1 = k + 1; i1 < n; i1++)
                for (index i2 = k + 1; i2 < n; i2++)
                    A[i1][i2] -= A[i1][k] * A[k][i2];
        }
        else {
            cout << "Gauss_Elimination_Full:遇到奇异,求解失败退出\n";
            return cell(ERROR, b);
        }
        if (mode == detail) {
            cout << "第" << k << "次得到的u，v如下\n";
            PrintVector(u);
            PrintVector(v);
            cout << "\n第" << k << "次调整完成后\n";
            PrintMatrix(A);
        }
    }
    if (mode == detail) {
        cout << "k循环结束，分解得到的结果PAQ=LU\n";
        cout << "其中的u,v依次是\n";
        PrintVector(u);
        PrintVector(v);
        cout << "LU共存为\n";
        PrintMatrix(A);
        cout << "LU复原为PAQ\n";
        Recover_LU(A);
    }
    //开始求解
    vector<T> Pb(b); //Pb = PAx = LUQ^(-1)x 先求出 Pb = Ly 构造Pb向量
    for (i = 0; i < n; i++)
        Pb[i] = b[u[i]];          //翻译b->Pb
    Pb = Gauss_L_I(A, Pb).second; //求解Ly=Pb，得到的y记录在Pb
    cell temp = Gauss_U(A, Pb);
    if (temp.first != OK) { //U可以奇异失败
        cout << "Gauss_Elimination_Full:遇到奇异,求解失败退出\n";
        return cell(ERROR, b);
    } //求解UQ^(-1)x = y得到Q^(-1)x，仍记录在Pb
    else
        Pb = temp.second;
    for (i = 0; i < n; i++)
        b[v[i]] = Pb[i]; //翻译Q^(-1)x->x，结果记录回b

    if (mode == normal || mode == detail) {
        cout << "Gauss_Elimination_Full:解向量\n";
        PrintVector(b);
        if (mode == detail) {
            cout << "Gauss_Elimination_Full:其中左侧是LU=PAQ共存，右侧是解x\n";
            Print_Equation(A, b);
            for (index k = 0; k < n; k++)
                for (index j = 0; j < n; j++)
                    b2[k] -= constA[k][j] * b[j];
            T delta = 0;
            for (index k = 0; k < n; k++) {
                if (abs(b2[k]) > delta)
                    delta = abs(b2[k]);
            }
            cout << "Gauss_Elimination_Full:解向量的误差b-Ax的无穷范数=" << delta << endl;
        }
        cout << "Gauss_Elimination_Full:退出\n";
    }
    return cell(OK, b);
}

//列主元的高斯求解函数
cell Gauss_Elimination_Full_Column(const matrix &constA, const vector<T> &constb, const enum pattern mode = normal)
{
    if (!Check(constA, constb)) {
        cout << "Gauss_Elimination_Full_Column:矩阵尺寸异常,或矩阵与向量不兼容,失败退出\n";
        return cell(ERROR, constb);
    }
    matrix A(constA);
    vector<T> b(constb);
    index n = b.size(), i, p, temp_i; //p寻找当前列的主元，i用于向量操作，temp_i用于u的一些记录交换
    T Max;
    vector<T> u, temp_vector; //u用于记录行变换，temp_vector用于交换行
    matrix A2(A);
    vector<T> b2(b);
    if (mode != quiet)
        cout << "Gauss_Elimination_Full_Column:进入\n";
    for (i = 0; i < n; i++) //u标记向量初始化
        u.push_back(i);
    //PA = LU，其中P由u记录
    for (index k = 0; k < n - 1; k++) {
        //找最大元指标p,k
        Max = abs(A[k][k]);
        p = k;
        for (index p1 = k; p1 < n; p1++) {
            if (abs(A[p1][k]) > Max) {
                Max = abs(A[p1][k]);
                p = p1;
            }
        }
        if (mode == detail) {
            cout << "第" << k << "次调整前\n";
            PrintMatrix(A);
            cout << "第" << k << "次找到列最大元" << Max << "在 (" << p << "," << k << ")位置\n";
        }
        //交换k,p行
        temp_vector = A[k];
        A[k] = A[p];
        A[p] = temp_vector;
        //记录交换行为，u记录行变换;
        temp_i = u[k];
        u[k] = u[p];
        u[p] = temp_i;
        //主体部分，如果主元非退化
        if (A[k][k]) {
            for (index j = k + 1; j < n; j++)
                A[j][k] = A[j][k] / A[k][k];
            for (index i1 = k + 1; i1 < n; i1++)
                for (index i2 = k + 1; i2 < n; i2++)
                    A[i1][i2] -= A[i1][k] * A[k][i2];
        }
        else {
            cout << "Gauss_Elimination_Full_Column:遇到奇异,求解失败退出\n";
            return cell(ERROR, b);
        }
        if (mode == detail) {
            cout << "第" << k << "次得到的u如下\n";
            PrintVector(u);
            cout << "\n第" << k << "次调整完成后\n";
            PrintMatrix(A);
        }
    }
    if (mode == detail) {
        cout << "k循环结束，分解得到的结果PA=LU\n";
        cout << "其中的u是\n";
        PrintVector(u);
        cout << "LU共存为\n";
        PrintMatrix(A);
        cout << "LU复原为PA\n";
        Recover_LU(A);
    }
    //开始求解
    //Pb = PAx = LUx 先求出 Pb = Ly 构造Pb向量
    vector<T> temp_b(b);
    for (i = 0; i < n; i++)
        b[i] = temp_b[u[i]];    //Pb存在b中
    b = Gauss_L_I(A, b).second; //A直接作为L，得到的y记录在b
    cell temp = Gauss_U(A, b);
    if (temp.first != OK) { //U可以奇异失败
        cout << "Gauss_Elimination_Full_Column:遇到奇异,求解失败退出\n";
        return cell(ERROR, b);
    } //A直接作为U，求解Ux = y得到x，仍记录在b
    else
        b = temp.second;

    if (mode == normal || mode == detail) {
        cout << "Gauss_Elimination_Full_Column:解向量\n";
        PrintVector(b);
        if (mode == detail) {
            cout << "其中左侧是LU=PA共存，右侧是解x\n";
            Print_Equation(A, b);
            for (index k = 0; k < n; k++)
                for (index j = 0; j < n; j++)
                    b2[k] -= A2[k][j] * b[j];
            T delta = 0;
            for (index k = 0; k < n; k++) {
                if (abs(b2[k]) > delta)
                    delta = abs(b2[k]);
            }
            cout << "Gauss_Elimination_Full_Column:解向量的误差b-Ax的无穷范数\t" << delta << endl;
        }
        cout << "Gauss_Elimination_Full_Column:退出\n";
    }
    return cell(OK, b);
}

//全主元高斯求解函数的预处理
Gauss_prepared_cell Gauss_Elimination_Full_prepared(const matrix &constA)
{
    //进行预先的分解，存储行列的交换以及得到的LU矩阵，便于重复进行b不同的计算

    if (!Check(constA)) {
        cout << "Gauss_Elimination_Full_prepared:矩阵尺寸异常,失败退出\n";
        return Gauss_prepared_cell{ERROR, constA, constA[0], constA[0]};
    }
    matrix A(constA);
    index n = A[0].size(), i, p, q, temp_i; //n是尺寸，i用于向量操作，p,q寻找主元，temp_i用于u,v的一些记录交换
    T Max, temp_T;                          //Max记录最大元，temp_T用于交换列
    vector<T> u, v, temp_vector;            //u,v用于记录行列变换，temp_vector用于交换行
    for (i = 0; i < n; i++) {
        u.push_back(i); //u,v标记向量初始化
        v.push_back(i);
    }
    //PAQ = LU，其中P，Q分别由u，v记录
    for (index k = 0; k < n - 1; k++) {
        //找最大元指标p,q
        Max = abs(A[k][k]);
        p = q = k;
        for (index p1 = k; p1 < n; p1++) {
            for (index q1 = k; q1 < n; q1++) {
                if (abs(A[p1][q1]) > Max) {
                    Max = abs(A[p1][q1]);
                    p = p1;
                    q = q1;
                }
            }
        }
        //交换k,p行
        temp_vector = A[k];
        A[k] = A[p];
        A[p] = temp_vector;
        //交换k,q列
        for (i = 0; i < n; i++) {
            temp_T = A[i][k];
            A[i][k] = A[i][q];
            A[i][q] = temp_T;
        }
        //记录交换行为，u记录行变换，v记录列变换
        temp_i = u[k];
        u[k] = u[p];
        u[p] = temp_i;
        temp_i = v[k];
        v[k] = v[q];
        v[q] = temp_i;
        //主体部分，如果主元非退化
        if (A[k][k]) {
            for (index j = k + 1; j < n; j++)
                A[j][k] = A[j][k] / A[k][k];
            for (index i1 = k + 1; i1 < n; i1++)
                for (index i2 = k + 1; i2 < n; i2++)
                    A[i1][i2] -= A[i1][k] * A[k][i2];
        }
        else {
            cout << "Gauss_Elimination_Full_prepared:分解遇到奇异,失败退出\n";
            return Gauss_prepared_cell{ERROR, constA, constA[0], constA[0]};
        }
    }
    return Gauss_prepared_cell{OK, A, u, v};
}

//基于预处理后的快速求解函数
cell Gauss_quick(const Gauss_prepared_cell &pre, const vector<T> &constb, const enum pattern mode = quiet)
{
    //基于上一个函数已经得到全主元的PAQ，记录下来可以快速进行后续求解
    if (!Check(pre.A, constb)) {
        cout << "Gauss_quick:矩阵尺寸异常,或矩阵与向量不兼容,失败退出\n";
        return cell(ERROR, constb);
    }

    if (mode == normal || mode == detail) {
        cout << "Gauss_quick:进入\n";
    }
    //检验一下受到的Gauss_prepared_cell
    if (pre.s != OK) {
        cout << "Gauss_quick:收到未成功分解的Gauss_prepared_cell,不可求解,失败退出\n";
        return cell(ERROR, constb);
    }
    vector<T> b(constb), Pb(b);
    index n = b.size(), i;
    //开始求解
    //Pb = PAx = LUQ^(-1)x 先求出 Pb = Ly 构造Pb向量
    for (i = 0; i < n; i++)
        Pb[i] = b[pre.u[i]];          //翻译b->Pb
    Pb = Gauss_L_I(pre.A, Pb).second; //求解Ly=Pb，得到的y记录在Pb
    cell temp = Gauss_U(pre.A, Pb);
    if (temp.first != OK) { //U可以奇异失败
        cout << "Gauss_quick:遇到奇异,求解失败退出\n";
        return cell(ERROR, b);
    } //求解UQ^(-1)x = y得到Q^(-1)x，仍记录在Pb
    else
        Pb = temp.second;
    for (i = 0; i < n; i++)
        b[pre.v[i]] = Pb[i]; //翻译Q^(-1)x->x，结果记录回b
    if (mode == normal || mode == detail) {
        cout << "Gauss_quick:解向量\n";
        PrintVector(b);
        cout << "Gauss_quick:退出\n";
    }
    return cell(OK, b);
}

#endif