/*
支持的可选宏定义
INCLUDE_ALL
LONG_T 把T设置为long double

*/
#ifndef MY_HEAD
#define MY_HEAD
#include <cmath>
#include <ctime>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

//常数
#define OK 1
#define ERROR 0
//机器精度,以及另外两个可选的常数值
#define MACHINE_PRECISION 1e-15
#define MACHINE_TINY 1e-8
#define VIEW_SMALL 1e-5

using namespace std;

//如果要求高精度,需要在头文件之前define LONG_T,否则默认double
#ifdef LONG_T
typedef long double T;
#endif
#ifndef LONG_T
typedef double T;
#endif

typedef vector<vector<T>> matrix;
typedef unsigned int index;
typedef int Status;
//pair,状态加向量
typedef pair<Status, vector<T>> cell;
//pair,状态加值
typedef pair<Status, T> value;

//结构体,Householder变化的基本参数
typedef struct Householder_cell {
    vector<T> v;
    T beta;
} Householder_cell;

//结构体{状态,特征值,对应特征向量}
typedef struct Eigen_single_cell {
    Status s;
    T eigenvalue;
    vector<T> eigenvector;
} Eigen_single_cell;

//大型求解函数的模式选择
enum pattern {
    quiet = 1,
    normal,
    detail,
};

//写在头文件中的最基本的符号函数,0的符号取1
template <typename ty>
ty sign(ty a)
{
    return (a < 0) ? (-1) : 1;
}

//日志头文件以及预设的两个txt文件，注意文件夹

//#include "MyLog.h"
/*
MyLog log_head("head.txt");
MyLog log_important("important_head.txt");
*/

#endif //MY_HEAD


//定义INCLUDE_ALL将会include所有文件,适合main函数所在文件使用
#ifdef INCLUDE_ALL

//加一层保护
#ifndef INCLUDE_ALL_DONE
#define INCLUDE_ALL_DONE
#include "new_cholesky_kernel.cpp"
#include "new_eigen_power.cpp"
#include "new_eigen_qr.cpp"
#include "new_eigen_symmetric.cpp"
#include "new_gauss_kernel.cpp"
#include "new_iteration_kernel.cpp"
#include "new_matrix_base.cpp"
#include "new_matrix_operator.cpp"
#include "new_matrix_random.cpp"
#include "new_norm_kernel.cpp"
#include "new_pde_kernel.cpp"
#include "new_qr_kernel.cpp"
#include "new_svd.cpp"
#endif //INCLUDE_ALL_DONE

#endif //INCLUDE_ALL