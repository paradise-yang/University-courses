#include <iomanip>
#include <iostream>
#include <vector>
using namespace std;

typedef double T;
typedef std::vector<std::vector<T>> matrix;
typedef unsigned index;

typedef std::vector<std::vector<std::vector<T>>> super_matrix;
/*
//向量加法重载
vector<T> operator+(const vector<T> &u, const vector<T> &v)
{
    index m1 = u.size(), m2 = v.size();
    if (m1 == m2) {
        vector<T> w(m1, 0);
        for (index i = 0; i < m1; i++) {
            w[i] = u[i] + v[i];
        }
        return w;
    }
    else {
        printf("向量加法尺寸不相等\n");
        return u;
    }
}

//向量减法重载
vector<T> operator-(const vector<T> &u, const vector<T> &v)
{
    index m1 = u.size(), m2 = v.size();
    if (m1 == m2) {
        vector<T> w(m1, 0);
        for (index i = 0; i < m1; i++) {
            w[i] = u[i] - v[i];
        }
        return w;
    }
    else {
        printf("向量减法尺寸不相等\n");
        return u;
    }
}

//向量数乘重载*
vector<T> operator*(T x, const vector<T> &u)
{
    index m = u.size();
    vector<T> v(m, 0);
    for (index i = 0; i < m; i++) v[i] = x * u[i];
    return v;
}

//矩阵数乘重载*
matrix operator*(T x, const matrix &A)
{
    index m = A.size(), n = A[0].size();
    matrix B = A;
    for (index i = 0; i < m; i++)
        for (index j = 0; j < n; j++)
            B[i][j] = x * A[i][j];
    return B;
}

//矩阵加法重载+
matrix operator+(const matrix &A, const matrix &B)
{
    index m1 = A.size(), n1 = A[0].size();
    index m2 = B.size(), n2 = B[0].size();
    if (m1 == m2 && n1 == n2) {
        matrix C = A;
        for (index i = 0; i < m1; i++)
            for (index j = 0; j < n1; j++)
                C[i][j] = A[i][j] + B[i][j];
        return C;
    }
    else {
        printf("矩阵加法尺寸不对\n");
        return A;
    }
}

//矩阵减法重载-
matrix operator-(const matrix &A, const matrix &B)
{
    index m1 = A.size(), n1 = A[0].size();
    index m2 = B.size(), n2 = B[0].size();
    if (m1 == m2 && n1 == n2) {
        matrix C = A;
        for (index i = 0; i < m1; i++)
            for (index j = 0; j < n1; j++)
                C[i][j] = A[i][j] - B[i][j];
        return C;
    }
    else {
        printf("矩阵减法尺寸不对\n");
        return A;
    }
}

//矩阵转置
matrix transpose(const matrix &A)
{
    index m = A.size(), n = A[0].size();
    vector<T> temp(m, 0);
    matrix P(n, temp);

    for (index i = 0; i < n; i++)
        for (index j = 0; j < m; j++)
            P[i][j] = A[j][i];

    return P;
}

//矩阵乘法
matrix multiplyMatrix(const matrix &A, const matrix &B)
{
    index m1 = A.size(), m2 = B.size();
    index n1 = A[0].size(), n2 = B[0].size();
    vector<T> temp(n2, 0);
    matrix C(m1, temp);
    T sum = 0;
    if (m2 == n1) {
        for (index i = 0; i < m1; i++) {
            for (index j = 0; j < n2; j++) {
                sum = 0;
                for (index r = 0; r < m2; r++) {
                    sum += (A[i][r] * B[r][j]);
                }
                C[i][j] = sum;
            }
        }
        return C;
    }
    else {
        printf("矩阵乘法错误，尺寸不对");
        return A;
    }
}

//矩阵乘法重载*
matrix operator*(const matrix &A, const matrix &B)
{
    index m1 = A.size(), m2 = B.size();
    index n1 = A[0].size(), n2 = B[0].size();
    vector<T> temp(n2, 0);
    matrix C(m1, temp);
    T sum = 0;
    if (m2 == n1) {
        for (index i = 0; i < m1; i++) {
            for (index j = 0; j < n2; j++) {
                sum = 0;
                for (index r = 0; r < m2; r++) {
                    sum += (A[i][r] * B[r][j]);
                }
                C[i][j] = sum;
            }
        }
        return C;
    }
    else {
        printf("矩阵乘法错误，尺寸不对");
        return A;
    }
}


//向量乘法
T multiplyVector(const vector<T> &u, const vector<T> &v)
{
    index n1 = u.size(), n2 = v.size();
    T sum = 0;
    if (n1 == n2) {
        for (index i = 0; i < n1; i++) {
            sum = sum + (u[i] * v[i]);
        }
        return sum;
    }
    else {
        printf("向量内积错误，尺寸不对");
        return sum;
    }
}

//向量点乘重载*
T operator*(const vector<T> &u, const vector<T> &v)
{
    index n1 = u.size(), n2 = v.size();
    T sum = 0;
    if (n1 == n2) {
        for (index i = 0; i < n1; i++) {
            sum = sum + (u[i] * v[i]);
        }
        return sum;
    }
    else {
        printf("向量内积错误，尺寸不对");
        return sum;
    }
}

//矩阵乘以向量
vector<T> multiplyMatrixVector(const matrix &A, const vector<T> &b)
{
    index m = A.size();
    index n1 = A[0].size(), n2 = b.size();
    vector<T> result(m, 0);
    if (n1 == n2) {
        T sum = 0;
        for (index i = 0; i < m; i++) {
            sum = 0;
            for (index j = 0; j < n1; j++) {
                sum = sum + A[i][j] * b[j];
            }
            result[i] = sum;
        }
        return result;
    }
    else {
        printf("矩阵与向量乘法错误，尺寸不对");
        return result;
    }
}

//矩阵乘以向量，重载*
vector<T> operator*(const matrix &A, const vector<T> &b)
{
    index m = A.size();
    index n1 = A[0].size(), n2 = b.size();
    vector<T> result(m, 0);
    if (n1 == n2) {
        T sum = 0;
        for (index i = 0; i < m; i++) {
            sum = 0;
            for (index j = 0; j < n1; j++) {
                sum = sum + A[i][j] * b[j];
            }
            result[i] = sum;
        }
        return result;
    }
    else {
        printf("矩阵与向量乘法错误，尺寸不对");
        return result;
    }
}
*/
//矩阵输出
void readMatrix(const matrix &A)
{
    index m = A.size(), n = A[0].size();
    printf("------\n");
    for (index i = 0; i < m; i++) {
        for (index j = 0; j < n; j++) {
            printf("%f, ", A[i][j]);
        }
        printf("\n");
    }
    printf("------\n");
    return;
}

//矩阵输出
void readMatrix_plot(const matrix &A)
{
    index m = A.size(), n = A[0].size();
    printf("------\n{");
    for (index i = 0; i < m; i++) {
        printf("{");
        for (index j = 0; j < n; j++) {
            printf("%.12f", A[i][j]);
            if (j < n - 1) printf(",");
        }
        printf("}");
        if (i < m - 1) printf(",");
    }
    printf("}\n------\n");
    return;
}

//矩阵输出，mma格式的数组
void readsuperMatrix_plot(const super_matrix &A)
{
    index m1 = A.size(), m2 = A[0].size(), m3 = A[0][0].size();
    printf("------\n{");
    for (index i = 0; i < m1; i++) {
        printf("{");
        for (index j = 0; j < m2; j++) {
            printf("{");
            for (index k = 0; k < m3; k++) {
                printf("%f", A[i][j][k]);
                if (k < m3 - 1) printf(",");
            }
            printf("}");
            if (j < m2 - 1) printf(",");
        }
        printf("}");
        if (i < m1 - 1) printf(",\n");
    }
    printf("}\n------\n");
    return;
}

//向量输出，方便latex制表
void readVector(const vector<T> &u)
{
    index n = u.size();
    for (index i = 0; i < n; i++) {
        printf("%f ", u[i]);
    }
    printf("\n");
    return;
}

void readVector_e2(const vector<T> &u)
{
    index n = u.size();
    for (index i = 0; i < n; i++) {
        //cout << scientific << setprecision(4) << " & " << u[i];
        printf("& %.2E ", u[i]);
    }
    printf("\\\\\n");
    return;
}

void readVector_f2(const vector<T> &u)
{
    index n = u.size();
    for (index i = 0; i < n; i++) {
        //cout << scientific << setprecision(4) << " & " << u[i];
        printf("& %.2f ", u[i]);
    }
    printf("\\\\\n");
    return;
}

//写一个快速生成相应尺寸的矩阵函数
matrix newMatrix(index m, index n, T e = 0)
{
    vector<T> temp(n, e);
    matrix result(m, temp);
    return result;
}

//写一个绝对值函数
T myabs(T x)
{
    if (x < 0) return -x;
    return x;
}

vector<T> myabs(const vector<T> &u)
{
    index n = u.size();
    vector<T> v(n, 0);
    for (index i = 0; i < n; i++) {
        v[i] = myabs(u[i]);
    }
    return v;
}

vector<T> thomas(const vector<T> &a, const vector<T> &b, const vector<T> &c, const vector<T> &d)
{
    index na = a.size(), nb = b.size(), nc = c.size(), nd = d.size();
    vector<T> x(na, 0);
    if (na != nb || na != nc || na != nd) {
        printf("thomas:尺寸不相等\n");
        return x;
    }
    vector<T> beta = b;
    vector<T> y = d;
    T temp = 0;

    beta[0] = b[0];
    y[0] = d[0];
    for (index i = 1; i < na; i++) {
        temp = a[i] / beta[i - 1];
        beta[i] -= (temp * c[i - 1]);
        y[i] -= (temp * y[i - 1]);
    }

    x[na - 1] = y[na - 1] / beta[na - 1];
    for (index i = na - 1; i > 0; i--) {
        //注意下标
        x[i - 1] = (y[i - 1] - c[i - 1] * x[i]) / beta[i - 1];
    }

    return x;
}

vector<T> thomas(const matrix &constA, const vector<T> &constd)
{
    index na = constA.size(), na2 = constA[0].size(), nd = constd.size();
    vector<T> x(na2, 0);
    if (na != na2 || na != nd) {
        printf("thomas:尺寸不相等\n");
        return x;
    }
    matrix A = constA;
    vector<T> d = constd;
    T temp = 0;
    for (index i = 1; i < na; i++) {
        temp = A[i][i - 1] / A[i - 1][i - 1];
        A[i][i] -= (temp * A[i - 1][i]);
        d[i] -= (temp * d[i - 1]);
    }

    x[na - 1] = d[na - 1] / A[na - 1][na - 1];
    for (index i = na - 1; i > 0; i--) {
        //注意下标
        x[i - 1] = (d[i - 1] - A[i - 1][i] * x[i]) / A[i - 1][i - 1];
    }
    return x;
}

/*

//流<<打印向量,注意这里按照可复制的超高标准进行输出
std::ostream &operator<<(std::ostream &os, const std::vector<T> &v)
{
    os << "{";
    index n = v.size();
    if (n < 1) {
        os << "}";
        return os;
    }
    for (index i = 0; i < n - 1; i++) {
        os << v[i] << ",";
    }
    os << v[n - 1];
    os << "}";
    return os;
}

//流<<打印矩阵,基于流<<打印向量,注意这里按照可复制的超高标准进行输出
std::ostream &operator<<(std::ostream &os, const matrix &m)
{
    index n = m.size();
    os << "{";
    if (n < 1) {
        os << "}";
        return os;
    }
    for (index i = 0; i < n - 1; i++) {
        os << fixed<< setprecision(6) << m[i] << ",";
    }
    os << fixed<< setprecision(6) << m[n - 1] << "}";
    return os;
}
*/