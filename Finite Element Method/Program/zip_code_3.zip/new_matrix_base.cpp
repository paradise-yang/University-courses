//整理一次完成
#ifndef MY_MATRIX_BASE
#define MY_MATRIX_BASE
#include "new_head.h"
#include <iomanip> //用于输入输出的格式操纵


//基本向量打印函数,结尾自带换行
void PrintVector(const std::vector<T> &v)
{
    for (auto op = v.begin(); op != v.end(); ++op) std::cout << *op << " ";
    std::cout << std::endl; //自动换行
    return;
}

//更高精度的向量打印,并且退出前恢复精度,结尾自带换行
void PrintVector_Plus(const vector<T> &v)
{
    std::cout << std::setprecision(30);
    for (auto op = v.begin(); op != v.end(); ++op) std::cout << *op << " ";
    std::cout << std::endl; //自动换行
    std::cout << std::setprecision(6);
    return;
}

//基本矩阵打印函数,依赖向量打印函数实现
void PrintMatrix(const matrix &m)
{
    index n = m.size();
    for (index i = 0; i < n; i++) PrintVector(m[i]);
    return;
}


//清理向量
void Clear(vector<T> &v)
{
    for (auto op = v.begin(); op != v.end(); ++op) *op = 0;
    return;
}

//清理矩阵,基于清理向量
void Clear(matrix &A)
{
    for (auto op = A.begin(); op != A.end(); ++op) Clear(*op);
    return;
}

//返回一个深复制的副本
vector<T> Copy(const vector<T> &v)
{
    vector<T> u(v);
    return u;
}
//返回一个深复制的副本
matrix Copy(const matrix &A)
{
    matrix B(A);
    return B;
}



//向量范数:p = 0 无穷范数,最大模指标通过p返回
//还支持 p = 1,p = 2
T Norm_of_vector(const vector<T> &b, index &p)
{
    index n = b.size(), j = 0;
    long double s = 0;
    if (p == 0) {
        for (index i = 0; i < n; i++) {
            if (abs(b[i]) > s) {
                s = abs(b[i]);
                j = i;
            }
        }
        p = j; // p返回最大模指标
        return (T)s;
    }
    else if (p == 1) {
        for (index i = 0; i < n; i++) s += abs(b[i]);
        return (T)s;
    }
    else if (p == 2) {
        for (index i = 0; i < n; i++) s += b[i] * b[i];
        return (T)sqrt(s);
    }
    else {
        cout << "Norm_of_vector:仅支持常用的无穷,一,二范数\n";
        return 0;
    }
}

//三个基础的向量范数函数,有集成版本Norm_of_vector可以替代
//但是大量现有函数调用,为了速度不予删除
T Two_norm(const vector<T> &b)
{
    index n = b.size();
    long double s = 0;
    for (index i = 0; i < n; i++) s += b[i] * b[i];
    return (T)sqrt(s);
}

T One_norm(const vector<T> &b)
{
    index n = b.size();
    T s = 0;
    for (index i = 0; i < n; i++) s += abs(b[i]);
    return s;
}

T Infinity_norm(const vector<T> &b)
{
    index n = b.size();
    T s = 0;
    for (index i = 0; i < n; i++) {
        if (abs(b[i]) > s) s = abs(b[i]);
    }
    return s;
}

index Infinity_norm_index(const vector<T> &b)
{
    index n = b.size(), j = 0;
    T s = 0;
    for (index i = 0; i < n; i++)
        if (abs(b[i]) > s) //曾经这个abs的括号害我扣了一分，记一笔
        {
            s = abs(b[i]);
            j = i;
        }
    return j;
}

T Infinity_norm_of_matrix(const matrix &A)
{
    index n = A.size(), i = 0;
    T s = 0;
    vector<T> temp(n);
    for (i = 0; i < n; i++) temp[i] = One_norm(A[i]);
    for (i = 0; i < n; i++) {
        if (temp[i] > s) s = temp[i];
    }
    return s;
}

//三个重载的check函数，检查矩阵尺寸，矩阵与向量的尺寸，矩阵与矩阵尺寸是否矛盾
//检查是否是整齐的矩阵
Status Check(const matrix &A)
{
    //检查是否是矩阵
    index n = A.size();
    if (n < 1) {
        cout << "Check:检测到空矩阵\n";
        return ERROR;
    }
    index m = A[0].size();
    if (m < 2) {
        cout << "Check:注意 此矩阵阶数小于2*2\n";
    }
    for (index i = 0; i < n; i++)
        if (A[i].size() != m) {
            cout << "Check:矩阵行向量不齐\n";
            return ERROR;
        }
    return OK;
}

//检查系数矩阵与向量是否兼容
//因为牵扯太多，只支持方阵系数矩阵
Status Check(const matrix &L1, const vector<T> &b)
{
    //检查Ax=b方程组中，A是否为n*n，b是否为n维向量
    index m = L1.size();
    if (m < 1) {
        cout << "Check:检测到空矩阵\n";
        return ERROR;
    }
    index n = L1[0].size();
    if (n < 1) {
        cout << "Check:检测到空矩阵\n";
        return ERROR;
    }
    for (index i = 0; i < m; i++) {
        if (L1[i].size() != n) {
            cout << "Check:系数矩阵行向量不齐\n";
            return ERROR;
        }
    }
    if (b.size() != n) {
        cout << "Check:系数矩阵与向量不匹配\n";
        return ERROR;
    }
    else if (n < 2) {
        cout << "Check:注意 此系数矩阵宽度与向量阶数小于2\n";
        return OK;
    }
    else
        return OK;
}

//矩阵加减时，检查两个矩阵尺寸是否相等
Status Check(const matrix &L1, const matrix &L2)
{
    index m = L1.size(), n = L2.size();
    if (m < 1 || n < 1) {
        cout << "Check:空矩阵试图加减\n";
        return ERROR;
    }
    if (m != n) {
        cout << "Check:试图加减的矩阵与矩阵行数不相等\n";
        return ERROR;
    }
    index h1 = L1[0].size(), h2 = L2[0].size();
    if (h1 != h2) {
        cout << "Check:试图加减的矩阵与矩阵列数不相等\n";
        return ERROR;
    }
    for (index i = 0; i < n; i++) {
        if (L1[i].size() != h1 || L2[i].size() != h2) {
            cout << "Check:试图加减的矩阵自身不齐\n";
            return ERROR;
        }
    }
    return OK;
}

//检查矩阵是否为对称矩阵
Status Check_symmetric(const matrix &A)
{
    if (!Check(A) || A[0].size() != A.size()) {
        cout << "Check_symmetric:矩阵尺寸异常或非方阵\n";
        return ERROR;
    }
    index n = A.size();
    for (index i = 0; i < n; i++)
        for (index j = 0; j < i; j++)
            if (A[i][j] != A[j][i]) {
                cout << "Check_symmetric:矩阵非对称\n";
                return ERROR;
            }
    return OK;
}

//矩阵转置,返回转置后的矩阵
matrix Transposition(const matrix &A)
{
    if (!Check(A)) {
        cout << "Transposition:矩阵尺寸异常,不支持转置\n";
        return A;
    }
    index m = A.size(), n = A[0].size();
    matrix B(n);
    for (index i = 0; i < n; i++)
        for (index j = 0; j < m; j++) B[i].push_back(A[j][i]);
    return B;
}

//矩阵就地转置,修改原件,
//加速版本,放弃矩阵检查,可能操作越界
//仅支持方阵操作,对于非方阵自动调用Transposition
Status Transposition_plus(matrix &A)
{
    index n = A.size();
    T temp = 0;
    if (A[0].size() != n) {
        cout << "Transposition_plus:就地转置不支持非方阵,自动使用Transposition\n";
        A = Transposition(A);
        return ERROR;
    }
    for (index i = 0; i < n; i++)
        for (index j = i + 1; j < n; j++) {
            temp = A[i][j];
            A[i][j] = A[j][i];
            A[j][i] = temp;
        }
    return OK;
}

//打印方程组的系数矩阵和向量,包括行号
Status Print_Equation(const matrix &L, const vector<T> &b)
{
    if (!Check(L, b)) {
        cout << "Print_Equation:系数矩阵与向量不兼容\n";
        return ERROR;
    }
    index m = L.size(), n = L[0].size();
    for (index i = 0; i < m; i++) {
        cout << "[" << i << ']';
        for (index j = 0; j < n; j++) cout << L[i][j] << " ";
        cout << "\t" << b[i] << "\n";
    }
    cout << endl;
    return OK;
}

//矩阵相加,返回结果矩阵
matrix Add_Matrix(const matrix &L, const matrix &P)
{
    if (!Check(L, P)) {
        cout << "Add_Matrix:矩阵不能相加减\n";
        return L;
    }
    index m = L.size(), n = L[0].size();
    vector<T> B0(n);
    matrix B(m, B0);
    for (index i = 0; i < m; i++)
        for (index j = 0; j < n; j++) B[i][j] = L[i][j] + P[i][j];
    return B;
}

//矩阵相减,返回结果矩阵
matrix Substract_Matrix(const matrix &L, const matrix &P)
{
    if (!Check(L, P)) {
        cout << "Substract_Matrix:矩阵不能相加减\n";
        return L;
    }
    index m = L.size(), n = L[0].size();
    vector<T> B0(n);
    matrix B(m, B0);
    for (index i = 0; i < m; i++)
        for (index j = 0; j < n; j++) B[i][j] = L[i][j] - P[i][j];
    return B;
}

//矩阵相乘,返回结果矩阵
matrix Multiply_Matrix(const matrix &A, const matrix &B)
{
    if (!Check(A) || !Check(B)) {
        cout << "Multiply_Matrix:矩阵自身尺寸异常\n";
        return A;
    }
    index m1 = A.size(), m2 = B.size(), n1 = A[0].size(), n2 = B[0].size();
    if (n1 != m2) {
        cout << "Multiply_Matrix:矩阵之间不可相乘\n";
        return A;
    }
    vector<T> C0(n2);
    matrix C(m1, C0);
    //三重循环暴力矩阵乘法
    for (index i = 0; i < m1; i++)
        for (index j = 0; j < n2; j++)
            for (index k = 0; k < n1; k++) C[i][j] += A[i][k] * B[k][j];
    return C;
}

//矩阵与向量相乘,返回向量
vector<T> Multiply_Matrix_Vector(const matrix &A, const vector<T> &b)
{
    if (!Check(A) || A[0].size() != b.size()) {
        cout << "Multiply_Matrix_Vector:矩阵异常,或不合理的矩阵和向量相乘\n";
        return b;
    }
    index m = A.size(), n = A[0].size();
    vector<T> d(m);
    for (index i = 0; i < m; i++) {
        for (index j = 0; j < n; j++) d[i] += A[i][j] * b[j];
    }
    return d;
}

//向量与向量相乘,得到矩阵
matrix Multiply_Vectors_to_Matrix(const vector<T> &u, const vector<T> &v)
{
    //返回u.vT
    index m = u.size(), n = v.size();
    if (m < 1) {
        cout << "Multiply_Vectors_to_Matrix:错误,试图用空向量生成矩阵\n";
        matrix A{{0}};
        return A;
    }
    else {
        vector<T> A0(n);
        matrix A(m, A0);
        for (index i = 0; i < m; i++) {
            for (index j = 0; j < n; j++) A[i][j] = u[i] * v[j];
        }
        return A;
    }
}

//向量与向量点乘,得到数值
T Multiply_Vectors_to_T(const vector<T> &b, const vector<T> &p)
{
    index n = b.size();
    if (n != p.size()) {
        cout << "Multiply_Vectors_to_T:错误,试图对长度不同的向量点乘\n";
        return 0;
    }
    else {
        T s = 0;
        for (index i = 0; i < n; i++) s += b[i] * p[i];
        return s;
    }
}

//生成单位方阵
matrix Init_Identity_matrix(index length, T key = 1, int move = 0, T other = 0)
{
    vector<T> b(length, other);
    matrix A(length, b);
    if (move >= 0) {
        for (index i = 0; i < length - move; i++) A[i][i + move] = key;
    }
    else {
        for (index j = -move; j < length; j++) A[j][j + move] = key;
    }
    return A;
}

//生成纯量矩阵,所有元素相同
matrix Init_Matrix(index m, index n, T everyone = 0)
{
    // m*n阶全是everyone的矩阵
    vector<T> b(n, everyone);
    matrix A(m, b);
    return A;
}


//分析2阶方阵的特征值
//对于实根,返回OK和两个特征值
//对于复根,返回ERROR和实部虚部
cell Analysis_Matrix22(const matrix &A)
{
    vector<T> result(2, 0);
    if (!Check(A) || A.size() != 2 || A[0].size() != 2) {
        cout << "Analysis_Matrix22:错误，输入的不是2x2矩阵\n";
        return cell(ERROR, result);
    }
    T a = A[0][0], b = A[0][1], c = A[1][0], d = A[1][1];
    T det = a * d - b * c, tr = a + d;
    T delta = tr * tr - 4 * det; //二次方程判别式
    T x = tr / 2, y = sqrt(abs(delta)) / 2;
    if (delta >= 0) {
        result[0] = x + y;
        result[1] = x - y;
        return cell(OK, result); //表示有两个实根，返回两个值
    }
    else {
        result[0] = x;
        result[1] = y;
        return cell(ERROR, result); //表示有共轭复根，返回的是实部虚部
    }
}



#endif