#ifndef MY_MATRIX_OPERATOR
#define MY_MATRIX_OPERATOR
#include "new_head.h"
#include "new_matrix_base.cpp"
#include <iomanip> //用于输入输出的格式操纵

//流打印向量有两套版本
//第一套格式是普通的
//第二套格式是超高精度，可以直接复制(并且自动舍弃过小的量)
//OPERATOR_PRECISION_TO_COPY被宏定义则采用第二种


//对向量和矩阵的打印输出<<进行了重载
//对向量,矩阵的加减+-进行了重载
//对矩阵乘法*,向量点乘*进行了重载
//没有实现矩阵乘向量,向量乘向量得到矩阵的两种运算重载
//额外实现了向量与矩阵的数乘,也是*

//实现了向量和矩阵的等号== !=重载
//考虑到浮点数性质，这里采用相对误差与机器精度相比较

//流<<打印向量,注意这里按照可复制的超高标准进行输出

#ifdef OPERATOR_PRECISION_TO_COPY
std::ostream &operator<<(std::ostream &os, const std::vector<T> &v)
{
    os << "{";
    index n = v.size();
    if (n < 1) {
        os << "}";
        return os;
    }
    os << std::setprecision(5);
    for (index i = 0; i < n - 1; i++) {
        if (abs(v[i]) > MACHINE_TINY) {
            os << v[i] << ",";
        }
        else
            os << 0 << ",";
        if ((i + 1) % 20 == 0) os << "\n";
    }
    if (abs(v[n - 1]) > MACHINE_TINY) {
        os << v[n - 1] << "}";
    }
    else {
        os << 0 << "}";
    }
    os << std::setprecision(6);
    return os;
}

//流<<打印矩阵,基于流<<打印向量,注意这里按照可复制的超高标准进行输出
std::ostream &operator<<(std::ostream &os, const matrix &m)
{
    index n = m.size();
    os << "{";
    if (n < 1) {
        os << "}";
        return os;
    }
    for (index i = 0; i < n - 1; i++) {
        os << m[i] << ",";
        if (n > 5) os << "\n";
    }
    os << m[n - 1] << "}";
    return os;
}
#endif

#ifndef OPERATOR_PRECISION_TO_COPY
//流<<打印向量
std::ostream &operator<<(std::ostream &os, const std::vector<T> &v)
{
    for (auto op = v.begin(); op != v.end(); ++op)
        os << *op << " ";
    os << std::endl; //自动换行
    return os;
}

//流<<打印矩阵,基于流<<打印向量
std::ostream &operator<<(std::ostream &os, const matrix &m)
{
    index n = m.size();
    for (index i = 0; i < n; i++)
        os << m[i];
    return os;
}
#endif


//向量加减的重载运算符
//向量加减只会按照最短的向量长度进行
vector<T> operator+(const vector<T> &u, const vector<T> &v)
{
    index m = u.size(), n = v.size();
    index k = (m > n) ? n : m;
    if (m != n) {
        cout << "operator+:警告,不等长向量加减,依照短的长度进行\n";
    }
    if (k == 0) {
        cout << "operator+:空的向量相加,错误\n";
        return u;
    }
    vector<T> result(k);
    for (index i = 0; i < k; i++) {
        result[i] = u[i] + v[i];
    }
    return result;
}
//向量加减的重载运算符
vector<T> operator-(const vector<T> &u, const vector<T> &v)
{
    index m = u.size(), n = v.size();
    index k = (m > n) ? n : m;
    if (m != n) {
        cout << "operator-:警告不等长向量加减,依照短的长度进行\n";
    }
    if (k == 0) {
        cout << "operator-:空的向量相减,错误\n";
        return u;
    }
    vector<T> result(k);
    for (index i = 0; i < k; i++) {
        result[i] = u[i] - v[i];
    }
    return result;
}

//矩阵加减的重载运算符
matrix operator+(const matrix &L, const matrix &P)
{
    if (!Check(L, P)) {
        cout << "operator+:矩阵不能相加减\n";
        return L;
    }
    index m = L.size(), n = L[0].size();
    vector<T> B0(n);
    matrix B(m, B0);
    for (index i = 0; i < m; i++)
        for (index j = 0; j < n; j++) B[i][j] = L[i][j] + P[i][j];
    return B;
}

//矩阵加减的重载运算符
matrix operator-(const matrix &L, const matrix &P)
{
    if (!Check(L, P)) {
        cout << "operator+:矩阵不能相加减\n";
        return L;
    }
    index m = L.size(), n = L[0].size();
    vector<T> B0(n);
    matrix B(m, B0);
    for (index i = 0; i < m; i++)
        for (index j = 0; j < n; j++) B[i][j] = L[i][j] - P[i][j];
    return B;
}

//矩阵相乘的运算符重载版本,返回结果矩阵
matrix operator*(const matrix &A, const matrix &B)
{
    if (!Check(A) || !Check(B)) {
        cout << "operator*:矩阵自身尺寸异常\n";
        return A;
    }
    index m1 = A.size(), m2 = B.size(), n1 = A[0].size(), n2 = B[0].size();
    if (n1 != m2) {
        cout << "operator*:矩阵之间不可相乘\n";
        return A;
    }
    vector<T> C0(n2);
    matrix C(m1, C0);
    //三重循环暴力矩阵乘法
    for (index i = 0; i < m1; i++)
        for (index j = 0; j < n2; j++)
            for (index k = 0; k < n1; k++) C[i][j] += A[i][k] * B[k][j];
    return C;
}

//向量与向量点乘,得到数值
T operator*(const vector<T> &b, const vector<T> &p)
{
    index n = b.size();
    if (n != p.size()) {
        cout << "operator*:错误,试图对长度不同的向量点乘\n";
        return 0;
    }
    else {
        T s = 0;
        for (index i = 0; i < n; i++) s += b[i] * p[i];
        return s;
    }
}

//向量的数乘
vector<T> operator*(T k, const vector<T> &v)
{
    index n = v.size();
    vector<T> result(v);
    for (index i = 0; i < n; i++) result[i] = k * result[i];
    return result;
}

//矩阵的数乘
//由于没有相应的函数只有向量数乘的重载,因此没有依赖向量数乘
matrix operator*(T k, const matrix &A)
{
    index m = A.size(), n = 0;
    matrix B(A);
    for (index i = 0; i < m; i++) {
        n = A[i].size();
        for (index j = 0; j < n; j++) B[i][j] = k * B[i][j];
    }
    return B;
}

//向量比较相等
bool operator==(const vector<T> &u, const vector<T> &v)
{
    index m = u.size(), n = v.size();
    if (m != n) { //不等长绝对不等
        return false;
    }
    if (m == 0 && n == 0) {
        return true;
    }
    vector<T> result(m);
    for (index i = 0; i < m; i++) { //这里要求k不为0
        if ((abs(u[i]) + abs(v[i])) > MACHINE_TINY && abs(u[i] - v[i]) > MACHINE_PRECISION * (abs(u[i]) + abs(v[i]))) return false;
    }
    return true;
}

//向量比较不相等
bool operator!=(const vector<T> &u, const vector<T> &v)
{
    index m = u.size(), n = v.size();
    if (m != n) { //不等长绝对不等
        return true;
    }
    if (m == 0 && n == 0) {
        return false;
    }
    vector<T> result(m);
    for (index i = 0; i < m; i++) { //这里要求k不为0
        if ((abs(u[i]) + abs(v[i])) > MACHINE_TINY && abs(u[i] - v[i]) > MACHINE_PRECISION * (abs(u[i]) + abs(v[i]))) return true;
    }
    return false;
}

//这个有问题
T diff(const vector<T> &u, const vector<T> &v)
{
    index m = u.size(), n = v.size();
    T s = 0;
    if (m != n) { //不等长绝对不等
        return -233;
    }
    if (m == 0 && n == 0) {
        return -100;
    }
    vector<T> result(m);
    for (index i = 0; i < m; i++) { //这里要求k不为0
        if (abs(u[i] - v[i]) / (abs(u[i]) + abs(v[i])) > s) {
            s = abs(u[i] - v[i]) / (abs(u[i]) + abs(v[i]));
        }
    }
    return s;
}

//矩阵比较相等
//不一定要求尺寸整齐的矩阵，不整齐也可比较
bool operator==(const matrix &L, const matrix &P)
{
    index m = L.size(), n = 0;
    for (index i = 0; i < m; i++) {
        n = L[i].size();
        for (index j = 0; j < n; j++)
            if ((abs(L[i][j]) + abs(P[i][j])) > MACHINE_TINY && abs(L[i][j] - P[i][j]) > MACHINE_PRECISION * (abs(L[i][j]) + abs(P[i][j]))) return false;
    }
    return true;
}

//矩阵比较不相等
bool operator!=(const matrix &L, const matrix &P)
{
    index m = L.size(), n = 0;
    for (index i = 0; i < m; i++) {
        n = L[i].size();
        for (index j = 0; j < n; j++)
            if ((abs(L[i][j]) + abs(P[i][j])) > MACHINE_TINY && abs(L[i][j] - P[i][j]) > MACHINE_PRECISION * (abs(L[i][j]) + abs(P[i][j]))) return true;
    }
    return false;
}


#endif