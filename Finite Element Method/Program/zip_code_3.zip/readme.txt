源代码绝大部分在a.cpp，包括main函数。
可以修改main函数的几个参数，输出表格或者点列(导出作图)，
或者输出误差数组(mma的格式)，用于复制到mma作出误差分布图。

基函数的定义在base_p.cpp
f(x)，d(x)，c(x)以及u(x)精确解的三种定义在information.cpp,information2.cpp,information3.cpp。必须选择其中一个在a.cpp中进行include。
information.cpp对应程序1的方程。
information2.cpp对应程序2的d(x),c(x)定义，并且精确解u(x)=(x-1)x
information3.cpp对应程序2的d(x),c(x)定义，并且精确解u(x)=(x-1)sin(x)

其他的.h和.cpp文件都是数值代数课留下的，包括高斯消元法，追赶法，以及矩阵的输出函数等。
放在同一目录下即可。

运行直接g++ a.cpp -o a.exe 即可