#include <iostream>
#include <stdio.h>
#include <vector>

using namespace std;

typedef double T;
typedef unsigned index;
typedef vector<vector<T>> matrix;


void test_1()
{
    vector<T> a = {0, -5, -5, -5};
    vector<T> b = {10, 10, 10, 10};
    vector<T> c = {-5, -5, -5, 0};
    vector<T> d = {0.2, 0.2, 0.2, 0.2};
    vector<T> x = thomas(a, b, c, d);
    for (index i = 0; i < x.size(); i++) {
        printf("%f\n", x[i]);
    }
printf("\n");
    index n = a.size();
    vector<T> temp(n, 0);
    matrix A(n, temp);
    for (index i = 1; i < n; i++) {
        A[i][i - 1] = a[i];
    }
    for (index i = 0; i < n; i++) {
        A[i][i] = b[i];
    }
    for (index i = 0; i < n - 1; i++) {
        A[i][i + 1] = c[i];
    }
    vector<T> x2 = thomas(A, d);
    for (index i = 0; i < x2.size(); i++) {
        printf("%f\n", x2[i]);
    }
}

/*
int main()
{
    test_1();
    return 0;
}
*/