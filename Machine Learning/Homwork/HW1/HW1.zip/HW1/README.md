Each row is a sample containing two numbers x and y, where x is the input feature and y is its corresponding response. Notice that, x and y are splited by '\t'.

For example, x is 0.025817872 and y is 1.072778871 in
```
0.025817872	1.072778871
```