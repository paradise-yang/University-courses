There are 100 data sets, named "data_i"(i=1,...,100), each having 25 rows. Each row is a sample containing two numbers x and y, where x is the input feature and y is its corresponding response.

For example, if x is -1.000000000 and y is -0.505178457, the data is
```
-1.000000000     -0.505178457
```