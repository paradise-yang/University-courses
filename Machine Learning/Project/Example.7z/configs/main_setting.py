params = {
        'env_name': 'Pong-v0',
        'evaluate':{
            'is_render': False,
            'num_evaluate_episodes':100,
        },
        'alg': 'PB00000000',

}