params = {
        'alg_name': 'random_policy',
        'max_iteration': 100,
        'batch_size': 100,
}